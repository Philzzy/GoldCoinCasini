package com.goldcoincasino.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CasinoColors = darkColorScheme(
    primary = Color(0xFFFFC857),
    onPrimary = Color(0xFF241A00),
    secondary = Color(0xFF8BD4A8),
    background = Color(0xFF071A12),
    surface = Color(0xFF0F2A1E),
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun GoldCoinCasinoTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = CasinoColors, content = content)
}
