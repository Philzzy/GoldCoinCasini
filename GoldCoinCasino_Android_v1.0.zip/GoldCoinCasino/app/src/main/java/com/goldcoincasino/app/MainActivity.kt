package com.goldcoincasino.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.goldcoincasino.app.ui.theme.GoldCoinCasinoTheme
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoldCoinCasinoTheme { CasinoApp() } }
    }
}

data class CasinoGame(val title: String, val subtitle: String, val icon: String, val screen: Screen)

enum class Screen { Lobby, Slots, Blackjack, Roulette, VideoPoker, Baccarat, Wallet, Profile, Info }

private val casinoGold = Color(0xFFFFC857)
private val casinoGreen = Color(0xFF071A12)
private val cardGreen = Color(0xFF102D20)
private val softText = Color(0xFFB8D2C2)
private val bets = listOf(50, 100, 250, 500)

@Composable
fun CasinoApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val store = remember { CasinoStore(context.applicationContext) }
    var screen by remember { mutableStateOf(Screen.Lobby) }
    var balance by remember { mutableIntStateOf(store.balance) }
    var canClaimDaily by remember { mutableStateOf(store.canClaimDaily()) }

    fun setBalance(newBalance: Int) {
        balance = newBalance.coerceAtLeast(0)
        store.balance = balance
    }

    fun wager(amount: Int): Boolean {
        if (balance < amount) return false
        setBalance(balance - amount)
        store.recordBet(amount)
        return true
    }

    fun payout(amount: Int) {
        if (amount <= 0) return
        setBalance(balance + amount)
        store.recordWin(amount)
    }

    Scaffold(
        containerColor = casinoGreen,
        bottomBar = {
            if (screen in listOf(Screen.Lobby, Screen.Wallet, Screen.Profile, Screen.Info)) {
                NavigationBar(containerColor = Color(0xFF0B2419)) {
                    NavigationBarItem(screen == Screen.Lobby, { screen = Screen.Lobby }, { Icon(Icons.Default.Home, null) }, label = { Text("Lobby") })
                    NavigationBarItem(screen == Screen.Wallet, { screen = Screen.Wallet }, { Icon(Icons.Default.AccountBalanceWallet, null) }, label = { Text("Wallet") })
                    NavigationBarItem(screen == Screen.Profile, { screen = Screen.Profile }, { Icon(Icons.Default.Person, null) }, label = { Text("Stats") })
                    NavigationBarItem(screen == Screen.Info, { screen = Screen.Info }, { Icon(Icons.Default.Info, null) }, label = { Text("Info") })
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (screen) {
                Screen.Lobby -> LobbyScreen(balance, canClaimDaily, onDailyBonus = {
                    if (store.claimDaily()) {
                        balance = store.balance
                        canClaimDaily = false
                    }
                }, onOpen = { screen = it })
                Screen.Slots -> SlotsScreen(balance, { screen = Screen.Lobby }, ::wager, ::payout)
                Screen.Blackjack -> BlackjackScreen(balance, { screen = Screen.Lobby }, ::wager, ::payout)
                Screen.Roulette -> RouletteScreen(balance, { screen = Screen.Lobby }, ::wager, ::payout)
                Screen.VideoPoker -> VideoPokerScreen(balance, { screen = Screen.Lobby }, ::wager, ::payout)
                Screen.Baccarat -> BaccaratScreen(balance, { screen = Screen.Lobby }, ::wager, ::payout)
                Screen.Wallet -> WalletScreen(balance, canClaimDaily, onClaim = {
                    if (store.claimDaily()) {
                        balance = store.balance
                        canClaimDaily = false
                    }
                })
                Screen.Profile -> ProfileScreen(store, balance, onReset = {
                    store.reset(); balance = store.balance; canClaimDaily = true
                })
                Screen.Info -> InfoScreen()
            }
        }
    }
}

@Composable
private fun Header(balance: Int, compact: Boolean = false) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = if (compact) 10.dp else 18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text("GOLD COIN", color = casinoGold, fontWeight = FontWeight.Black, fontSize = if (compact) 21.sp else 27.sp)
            Text("CASINO", color = Color.White, fontWeight = FontWeight.Bold, fontSize = if (compact) 14.sp else 17.sp)
        }
        Surface(shape = RoundedCornerShape(50), color = Color(0xFF153B2A)) {
            Text("🪙 ${"%,d".format(balance)}", color = Color(0xFFFFD978), fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp))
        }
    }
}

@Composable
private fun BackHeader(balance: Int, title: String, onBack: () -> Unit) {
    Column {
        Header(balance, compact = true)
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text(title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 23.sp)
        }
    }
}

@Composable
private fun LobbyScreen(balance: Int, dailyReady: Boolean, onDailyBonus: () -> Unit, onOpen: (Screen) -> Unit) {
    val games = listOf(
        CasinoGame("Lucky 7 Slots", "Classic 3-reel slot", "🎰", Screen.Slots),
        CasinoGame("Blackjack", "Beat the dealer to 21", "🃏", Screen.Blackjack),
        CasinoGame("European Roulette", "Single-zero wheel", "🎡", Screen.Roulette),
        CasinoGame("Video Poker", "Jacks or Better", "♠️", Screen.VideoPoker),
        CasinoGame("Baccarat", "Player • Banker • Tie", "♦️", Screen.Baccarat)
    )
    LazyColumn(Modifier.fillMaxSize()) {
        item { Header(balance) }
        item {
            Surface(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), RoundedCornerShape(22.dp), color = Color(0xFF132F23)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CardGiftcard, null, tint = casinoGold, modifier = Modifier.size(38.dp))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Daily Gold Bonus", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                        Text(if (dailyReady) "+2,500 Gold Coins" else "Come back tomorrow", color = softText)
                    }
                    Button(onClick = onDailyBonus, enabled = dailyReady) { Text(if (dailyReady) "Claim" else "Claimed") }
                }
            }
        }
        item { Text("Games", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp, modifier = Modifier.padding(18.dp, 22.dp, 18.dp, 8.dp)) }
        items(games) { game ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 7.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F2A1E)),
                onClick = { onOpen(game.screen) }
            ) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(game.icon, fontSize = 38.sp)
                    Spacer(Modifier.width(15.dp))
                    Column(Modifier.weight(1f)) {
                        Text(game.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(game.subtitle, color = Color(0xFF9FC2AE))
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = Color(0xFF8AA597))
                }
            }
        }
        item {
            Surface(Modifier.padding(18.dp).fillMaxWidth(), RoundedCornerShape(18.dp), color = Color(0xFF0D241A)) {
                Text("Entertainment only • Gold Coins have no cash value and cannot be redeemed for prizes or money.", color = Color(0xFF9AB7A6), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(14.dp))
            }
        }
    }
}

@Composable
private fun BetPicker(bet: Int, enabled: Boolean = true, onBet: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.Center) {
        bets.forEach { amount ->
            FilterChip(selected = bet == amount, enabled = enabled, onClick = { onBet(amount) }, label = { Text("$amount") }, modifier = Modifier.padding(horizontal = 3.dp))
        }
    }
}

@Composable
private fun SlotsScreen(balance: Int, onBack: () -> Unit, wager: (Int) -> Boolean, payout: (Int) -> Unit) {
    var reels by remember { mutableStateOf(listOf("7️⃣", "🍒", "🔔")) }
    var bet by remember { mutableIntStateOf(100) }
    var message by remember { mutableStateOf("Pick your bet and spin") }
    val symbols = listOf("7️⃣", "🍒", "🔔", "💎", "⭐")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        BackHeader(balance, "Lucky 7 Slots", onBack)
        Spacer(Modifier.height(12.dp))
        Surface(Modifier.padding(horizontal = 20.dp).fillMaxWidth(), RoundedCornerShape(24.dp), color = cardGreen) {
            Row(Modifier.padding(24.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                reels.forEach { symbol ->
                    Surface(shape = RoundedCornerShape(14.dp), color = Color(0xFFF5F0DE)) { Text(symbol, fontSize = 50.sp, modifier = Modifier.padding(12.dp)) }
                }
            }
        }
        Text(message, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth().padding(18.dp), textAlign = TextAlign.Center)
        Text("BET", color = softText, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        BetPicker(bet, onBet = { bet = it })
        Button(onClick = {
            if (!wager(bet)) { message = "Not enough Gold Coins"; return@Button }
            val r = List(3) { symbols[Random.nextInt(symbols.size)] }; reels = r
            val win = when {
                r.distinct().size == 1 && r[0] == "7️⃣" -> bet * 10
                r.distinct().size == 1 -> bet * 5
                r.groupingBy { it }.eachCount().values.any { it == 2 } -> bet * 2
                else -> 0
            }
            payout(win)
            message = when { win >= bet * 10 -> "JACKPOT! +${"%,d".format(win)}"; win > 0 -> "Winner! +${"%,d".format(win)}"; else -> "No win — spin again" }
        }, modifier = Modifier.fillMaxWidth().padding(28.dp, 8.dp).height(58.dp)) {
            Icon(Icons.Default.Casino, null); Spacer(Modifier.width(8.dp)); Text("SPIN • $bet COINS", fontWeight = FontWeight.Bold)
        }
        Paytable(listOf("7-7-7" to "10×", "Any 3 matching" to "5×", "Any pair" to "2×"))
    }
}

@Composable
private fun BlackjackScreen(balance: Int, onBack: () -> Unit, wager: (Int) -> Boolean, payout: (Int) -> Unit) {
    var bet by remember { mutableIntStateOf(100) }
    var deck by remember { mutableStateOf(shuffledDeck()) }
    var player by remember { mutableStateOf(emptyList<PlayingCard>()) }
    var dealer by remember { mutableStateOf(emptyList<PlayingCard>()) }
    var active by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Place a bet to deal") }

    fun finishRound() {
        var d = dealer.toMutableList()
        while (blackjackScore(d) < 17) d.add(deck.removeAt(0))
        dealer = d
        val pScore = blackjackScore(player); val dScore = blackjackScore(d)
        val result = when {
            pScore > 21 -> 0
            dScore > 21 || pScore > dScore -> bet * 2
            pScore == dScore -> bet
            else -> 0
        }
        payout(result)
        message = when { result == bet * 2 -> "You win! +${result - bet}"; result == bet -> "Push — bet returned"; else -> "Dealer wins" }
        active = false
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        BackHeader(balance, "Blackjack", onBack)
        HandPanel("Dealer", dealer, if (active && dealer.isNotEmpty()) "${dealer.first().display}  🂠" else dealer.joinToString("  ") { it.display }, if (!active && dealer.isNotEmpty()) blackjackScore(dealer).toString() else "")
        HandPanel("You", player, player.joinToString("  ") { it.display }, if (player.isNotEmpty()) blackjackScore(player).toString() else "")
        Text(message, color = casinoGold, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(12.dp))
        BetPicker(bet, enabled = !active, onBet = { bet = it })
        if (!active) {
            Button(onClick = {
                if (!wager(bet)) { message = "Not enough Gold Coins"; return@Button }
                deck = shuffledDeck()
                player = listOf(deck.removeAt(0), deck.removeAt(0)); dealer = listOf(deck.removeAt(0), deck.removeAt(0)); active = true
                message = "Hit or stand"
                if (blackjackScore(player) == 21) {
                    val blackjackPay = bet + (bet * 3 / 2)
                    payout(blackjackPay); message = "Blackjack! +${blackjackPay - bet}"; active = false
                }
            }, modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp)) { Text("DEAL • $bet COINS") }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 28.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = {
                    val p = player + deck.removeAt(0); player = p
                    if (blackjackScore(p) > 21) { message = "Bust — dealer wins"; active = false }
                    else if (blackjackScore(p) == 21) finishRound()
                }, modifier = Modifier.weight(1f)) { Text("HIT") }
                Button(onClick = { finishRound() }, modifier = Modifier.weight(1f)) { Text("STAND") }
            }
        }
        RulesText("Blackjack pays 3:2. Dealer stands on 17. Regular wins pay 1:1; pushes return the bet.")
    }
}

@Composable
private fun RouletteScreen(balance: Int, onBack: () -> Unit, wager: (Int) -> Boolean, payout: (Int) -> Unit) {
    var bet by remember { mutableIntStateOf(100) }
    var type by remember { mutableStateOf(RouletteBet.Red) }
    var number by remember { mutableIntStateOf(7) }
    var result by remember { mutableStateOf<Int?>(null) }
    var message by remember { mutableStateOf("Choose a wager and spin") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        BackHeader(balance, "European Roulette", onBack)
        Surface(Modifier.padding(18.dp).fillMaxWidth(), RoundedCornerShape(22.dp), color = cardGreen) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(result?.toString() ?: "?", color = if (result != null && result in rouletteReds) Color(0xFFE35D6A) else Color.White, fontSize = 64.sp, fontWeight = FontWeight.Black)
                Text(message, color = softText, textAlign = TextAlign.Center)
            }
        }
        Text("BET TYPE", color = softText, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        RouletteBet.entries.forEach { option ->
            Row(Modifier.fillMaxWidth().clickable { type = option }.padding(horizontal = 30.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = type == option, onClick = { type = option }); Text(option.label, color = Color.White)
            }
        }
        if (type == RouletteBet.Number) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { number = (number - 1).coerceAtLeast(0) }) { Icon(Icons.Default.Remove, null) }
                Text("$number", color = casinoGold, fontWeight = FontWeight.Black, fontSize = 28.sp, modifier = Modifier.padding(horizontal = 20.dp))
                IconButton(onClick = { number = (number + 1).coerceAtMost(36) }) { Icon(Icons.Default.Add, null) }
            }
        }
        BetPicker(bet, onBet = { bet = it })
        Button(onClick = {
            if (!wager(bet)) { message = "Not enough Gold Coins"; return@Button }
            val r = randomRouletteNumber(); result = r
            val win = roulettePayout(type, number, r, bet); payout(win)
            message = if (win > 0) "Winner! Payout ${"%,d".format(win)}" else "No win this spin"
        }, modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp)) { Text("SPIN • $bet COINS") }
        RulesText("Single-zero European wheel. Red/Black/Odd/Even pay 1:1. Straight-up number pays 35:1 plus the returned stake.")
    }
}

@Composable
private fun VideoPokerScreen(balance: Int, onBack: () -> Unit, wager: (Int) -> Boolean, payout: (Int) -> Unit) {
    var bet by remember { mutableIntStateOf(100) }
    var deck by remember { mutableStateOf(shuffledDeck()) }
    var hand by remember { mutableStateOf(emptyList<PlayingCard>()) }
    var held by remember { mutableStateOf(setOf<Int>()) }
    var drawing by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Deal five cards") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        BackHeader(balance, "Video Poker", onBack)
        Text(message, color = casinoGold, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.Center)
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.Center) {
            hand.forEachIndexed { index, card ->
                Surface(
                    modifier = Modifier.padding(3.dp).clickable(enabled = drawing) { held = if (index in held) held - index else held + index },
                    shape = RoundedCornerShape(10.dp), color = if (index in held) Color(0xFFFFE2A0) else Color.White
                ) {
                    Column(Modifier.padding(horizontal = 8.dp, vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(card.rank, color = Color.Black, fontWeight = FontWeight.Black, fontSize = 20.sp)
                        Text(card.suit, color = if (card.suit in listOf("♥","♦")) Color(0xFFB71C1C) else Color.Black, fontSize = 25.sp)
                        if (index in held) Text("HOLD", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp)); BetPicker(bet, enabled = !drawing, onBet = { bet = it })
        Button(onClick = {
            if (!drawing) {
                if (!wager(bet)) { message = "Not enough Gold Coins"; return@Button }
                deck = shuffledDeck(); hand = List(5) { deck.removeAt(0) }; held = emptySet(); drawing = true; message = "Tap cards to HOLD, then draw"
            } else {
                hand = hand.mapIndexed { index, card -> if (index in held) card else deck.removeAt(0) }
                val result = evaluatePoker(hand); val win = bet * result.multiplier; payout(win)
                message = if (win > 0) "${result.label}! Payout ${"%,d".format(win)}" else result.label
                drawing = false; held = emptySet()
            }
        }, modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp)) { Text(if (drawing) "DRAW" else "DEAL • $bet COINS") }
        Paytable(PokerHand.entries.filter { it.multiplier > 0 }.map { it.label to "${it.multiplier}×" })
    }
}

@Composable
private fun BaccaratScreen(balance: Int, onBack: () -> Unit, wager: (Int) -> Boolean, payout: (Int) -> Unit) {
    var bet by remember { mutableIntStateOf(100) }
    var choice by remember { mutableStateOf("Player") }
    var round by remember { mutableStateOf<BaccaratRound?>(null) }
    var message by remember { mutableStateOf("Choose Player, Banker, or Tie") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        BackHeader(balance, "Baccarat", onBack)
        val current = round
        HandPanel("Banker", current?.banker ?: emptyList(), current?.banker?.joinToString("  ") { it.display } ?: "—", current?.let { baccaratScore(it.banker).toString() } ?: "")
        HandPanel("Player", current?.player ?: emptyList(), current?.player?.joinToString("  ") { it.display } ?: "—", current?.let { baccaratScore(it.player).toString() } ?: "")
        Text(message, color = casinoGold, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth().padding(10.dp), textAlign = TextAlign.Center)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            listOf("Player", "Banker", "Tie").forEach { option -> FilterChip(choice == option, { choice = option }, { Text(option) }, modifier = Modifier.padding(4.dp)) }
        }
        BetPicker(bet, onBet = { bet = it })
        Button(onClick = {
            if (!wager(bet)) { message = "Not enough Gold Coins"; return@Button }
            val r = dealBaccarat(); round = r
            val win = when {
                choice != r.winner -> 0
                choice == "Player" -> bet * 2
                choice == "Banker" -> bankerPayout(bet)
                else -> bet * 9
            }
            payout(win); message = "${r.winner} wins" + if (win > 0) " • payout ${"%,d".format(win)}" else ""
        }, modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp)) { Text("DEAL • $bet COINS") }
        RulesText("Player pays 1:1. Banker pays 0.95:1 plus stake (5% commission). Tie pays 8:1 plus stake. Standard third-card drawing rules are applied.")
    }
}

@Composable
private fun HandPanel(title: String, hand: List<PlayingCard>, cardsText: String, scoreText: String) {
    Surface(Modifier.padding(horizontal = 18.dp, vertical = 7.dp).fillMaxWidth(), RoundedCornerShape(18.dp), color = cardGreen) {
        Column(Modifier.padding(18.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, color = softText, fontWeight = FontWeight.Bold); if (scoreText.isNotEmpty()) Text("Score $scoreText", color = casinoGold, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp)); Text(if (hand.isEmpty()) "—" else cardsText, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun Paytable(rows: List<Pair<String,String>>) {
    Surface(Modifier.padding(18.dp).fillMaxWidth(), RoundedCornerShape(16.dp), color = Color(0xFF0D241A)) {
        Column(Modifier.padding(14.dp)) {
            Text("PAYTABLE", color = casinoGold, fontWeight = FontWeight.Bold)
            rows.forEach { (name, pay) -> Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(name, color = softText); Text(pay, color = Color.White) } }
        }
    }
}

@Composable
private fun RulesText(text: String) {
    Text(text, color = Color(0xFF90AF9C), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(18.dp))
}

@Composable
private fun WalletScreen(balance: Int, dailyReady: Boolean, onClaim: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(balance)
        Text("Wallet", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 28.sp, modifier = Modifier.padding(horizontal = 18.dp))
        Surface(Modifier.padding(18.dp).fillMaxWidth(), RoundedCornerShape(20.dp), color = cardGreen) {
            Column(Modifier.padding(22.dp)) {
                Text("Gold Coin Balance", color = softText); Text("🪙 ${"%,d".format(balance)}", color = Color(0xFFFFD36B), fontWeight = FontWeight.Black, fontSize = 34.sp)
                Spacer(Modifier.height(20.dp)); Button(onClick = onClaim, enabled = dailyReady, modifier = Modifier.fillMaxWidth()) { Text(if (dailyReady) "CLAIM 2,500 DAILY COINS" else "DAILY BONUS CLAIMED") }
            }
        }
        Surface(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), RoundedCornerShape(20.dp), color = Color(0xFF132A20)) {
            Column(Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Lock, null, tint = casinoGold); Spacer(Modifier.width(8.dp)); Text("Real Money Mode", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp) }
                Spacer(Modifier.height(8.dp)); Text("Not available in this release. Gold Coins cannot be purchased for cash, redeemed, transferred, or converted to real-world value.", color = softText)
            }
        }
    }
}

@Composable
private fun ProfileScreen(store: CasinoStore, balance: Int, onReset: () -> Unit) {
    var confirmReset by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(balance)
        Text("Player Stats", color = Color.White, fontWeight = FontWeight.Black, fontSize = 28.sp, modifier = Modifier.padding(horizontal = 18.dp))
        StatCard("Games played", "${store.gamesPlayed}")
        StatCard("Total wagered", "🪙 ${"%,d".format(store.totalWagered)}")
        StatCard("Total payouts", "🪙 ${"%,d".format(store.totalWon)}")
        StatCard("Biggest payout", "🪙 ${"%,d".format(store.biggestWin)}")
        OutlinedButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth().padding(18.dp)) { Text("RESET LOCAL PROGRESS") }
    }
    if (confirmReset) AlertDialog(onDismissRequest = { confirmReset = false }, title = { Text("Reset progress?") }, text = { Text("This restores the starting 10,000 Gold Coins and clears local stats.") }, confirmButton = { TextButton(onClick = { onReset(); confirmReset = false }) { Text("Reset") } }, dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } })
}

@Composable
private fun StatCard(label: String, value: String) {
    Surface(Modifier.padding(horizontal = 18.dp, vertical = 5.dp).fillMaxWidth(), RoundedCornerShape(16.dp), color = cardGreen) {
        Row(Modifier.padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(label, color = softText); Text(value, color = Color.White, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun InfoScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Spacer(Modifier.height(10.dp)); Text("About Gold Coin Casino", color = Color.White, fontWeight = FontWeight.Black, fontSize = 28.sp)
        Spacer(Modifier.height(14.dp)); Text("A multi-game social casino using virtual Gold Coins for entertainment only.", color = softText, fontSize = 17.sp)
        InfoSection("Play-money only", "Gold Coins have no cash value. They cannot be redeemed, transferred, sold, or exchanged for prizes or money.")
        InfoSection("Responsible play", "Set personal time limits, take regular breaks, and treat every game as entertainment. Outcomes are randomized and there is no strategy that guarantees a win.")
        InfoSection("Privacy", "This release stores balance and statistics only on this device using Android local preferences. It does not require an account, contacts, location, or internet access.")
        InfoSection("Future real-money mode", "A future real-money product would be a separate regulated feature requiring jurisdiction-specific licensing, age and identity checks, geolocation, responsible-gambling controls, secure payments, auditing, and store approval before activation.")
        InfoSection("Version", "1.0.0 • Play-money release")
    }
}

@Composable
private fun InfoSection(title: String, body: String) {
    Surface(Modifier.padding(top = 14.dp).fillMaxWidth(), RoundedCornerShape(16.dp), color = cardGreen) {
        Column(Modifier.padding(18.dp)) { Text(title, color = casinoGold, fontWeight = FontWeight.Bold, fontSize = 18.sp); Spacer(Modifier.height(5.dp)); Text(body, color = softText) }
    }
}
