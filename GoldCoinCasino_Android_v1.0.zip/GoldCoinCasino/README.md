# Gold Coin Casino — Android v1.0.0

A complete offline play-money social casino built with Kotlin and Jetpack Compose.

## Playable games
- Lucky 7 Slots
- Blackjack
- European Roulette (single zero)
- Jacks or Better Video Poker
- Baccarat with standard third-card drawing rules

## Player features
- 10,000 Gold Coin starting balance
- Persistent local wallet
- 2,500 Gold Coin daily reward (once per calendar day)
- Bet levels: 50 / 100 / 250 / 500
- Persistent games-played, wagered, payout and biggest-payout statistics
- Local progress reset
- In-app game rules, privacy summary and responsible-play information

## Play-money design
Gold Coins have no cash value and cannot be redeemed, sold, transferred, or exchanged for prizes. The app does not request internet, contacts, location, camera, microphone, or payment permissions.

A future real-money product must use a separate server-authoritative wallet/game platform and must not convert this local Gold Coin ledger to cash.

## Current Android toolchain
- Kotlin 2.3.21
- Android Gradle Plugin 9.3.0
- Gradle 9.5.0 requirement
- Compile SDK 37
- Target SDK 36
- Min SDK 26 (Android 8.0+)
- Jetpack Compose BOM 2026.08.00

## Open and run
1. Install current stable Android Studio (Quail 3 or compatible).
2. Open the `GoldCoinCasino` project folder.
3. Allow Android Studio to sync dependencies and use Gradle 9.5.0.
4. Run on an Android 8.0+ emulator or device.
5. For distribution, use **Build > Generate Signed App Bundle / APK** and sign with your own release keystore.

## Release boundary
This source is v1.0-ready for play-money testing/distribution. Google Play publishing still requires the owner's Play Console account, signing key, store listing assets, policy declarations, and developer identity steps. A regulated real-money mode is intentionally not implemented in this release.
