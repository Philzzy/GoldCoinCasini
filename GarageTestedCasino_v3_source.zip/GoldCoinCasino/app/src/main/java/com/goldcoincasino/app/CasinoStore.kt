package com.goldcoincasino.app

import android.content.Context
import java.time.LocalDate

class CasinoStore(context: Context) {
    private val prefs = context.getSharedPreferences("gold_coin_casino", Context.MODE_PRIVATE)

    var balance: Int
        get() = prefs.getInt("balance", STARTING_BALANCE)
        set(value) { prefs.edit().putInt("balance", value.coerceAtLeast(0)).apply() }

    var totalWagered: Long
        get() = prefs.getLong("total_wagered", 0L)
        set(value) { prefs.edit().putLong("total_wagered", value.coerceAtLeast(0)).apply() }

    var totalWon: Long
        get() = prefs.getLong("total_won", 0L)
        set(value) { prefs.edit().putLong("total_won", value.coerceAtLeast(0)).apply() }

    var gamesPlayed: Int
        get() = prefs.getInt("games_played", 0)
        set(value) { prefs.edit().putInt("games_played", value.coerceAtLeast(0)).apply() }

    var biggestWin: Int
        get() = prefs.getInt("biggest_win", 0)
        set(value) { prefs.edit().putInt("biggest_win", value.coerceAtLeast(0)).apply() }

    fun canClaimDaily(): Boolean = prefs.getString("daily_date", "") != LocalDate.now().toString()

    fun claimDaily(): Boolean {
        if (!canClaimDaily()) return false
        balance += DAILY_BONUS
        prefs.edit().putString("daily_date", LocalDate.now().toString()).apply()
        return true
    }

    fun recordBet(amount: Int) {
        totalWagered += amount
        gamesPlayed += 1
    }

    fun recordWin(payout: Int) {
        if (payout <= 0) return
        totalWon += payout
        if (payout > biggestWin) biggestWin = payout
    }

    fun reset() {
        prefs.edit().clear().apply()
    }

    companion object {
        const val STARTING_BALANCE = 10_000
        const val DAILY_BONUS = 2_500
    }
}
