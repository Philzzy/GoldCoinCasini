package com.goldcoincasino.app

import kotlin.math.roundToInt
import kotlin.random.Random

data class PlayingCard(val rank: String, val suit: String) {
    val display: String get() = "$rank$suit"
    val blackjackValue: Int get() = when (rank) {
        "A" -> 11
        "K", "Q", "J" -> 10
        else -> rank.toInt()
    }
}

fun shuffledDeck(): MutableList<PlayingCard> {
    val suits = listOf("♠", "♥", "♦", "♣")
    val ranks = listOf("A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K")
    return suits.flatMap { s -> ranks.map { r -> PlayingCard(r, s) } }.shuffled().toMutableList()
}

fun blackjackScore(hand: List<PlayingCard>): Int {
    var score = hand.sumOf { it.blackjackValue }
    var aces = hand.count { it.rank == "A" }
    while (score > 21 && aces > 0) {
        score -= 10
        aces--
    }
    return score
}

private fun baccaratCardValue(card: PlayingCard): Int = when (card.rank) {
    "A" -> 1
    "10", "J", "Q", "K" -> 0
    else -> card.rank.toInt()
}

fun baccaratScore(hand: List<PlayingCard>): Int = hand.sumOf(::baccaratCardValue) % 10

data class BaccaratRound(val player: List<PlayingCard>, val banker: List<PlayingCard>, val winner: String)

fun dealBaccarat(): BaccaratRound {
    val deck = shuffledDeck()
    val player = mutableListOf(deck.removeAt(0), deck.removeAt(0))
    val banker = mutableListOf(deck.removeAt(0), deck.removeAt(0))
    var p = baccaratScore(player)
    var b = baccaratScore(banker)
    if (p < 8 && b < 8) {
        var playerThird: PlayingCard? = null
        if (p <= 5) {
            playerThird = deck.removeAt(0)
            player.add(playerThird)
        }
        if (playerThird == null) {
            if (b <= 5) banker.add(deck.removeAt(0))
        } else {
            val t = baccaratCardValue(playerThird)
            val bankerDraws = when (b) {
                0, 1, 2 -> true
                3 -> t != 8
                4 -> t in 2..7
                5 -> t in 4..7
                6 -> t in 6..7
                else -> false
            }
            if (bankerDraws) banker.add(deck.removeAt(0))
        }
    }
    p = baccaratScore(player)
    b = baccaratScore(banker)
    val winner = when {
        p > b -> "Player"
        b > p -> "Banker"
        else -> "Tie"
    }
    return BaccaratRound(player, banker, winner)
}

val rouletteReds = setOf(1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36)

enum class RouletteBet(val label: String) { Red("Red"), Black("Black"), Odd("Odd"), Even("Even"), Number("Number") }

fun roulettePayout(type: RouletteBet, chosenNumber: Int, result: Int, bet: Int): Int {
    val win = when (type) {
        RouletteBet.Red -> result in rouletteReds
        RouletteBet.Black -> result != 0 && result !in rouletteReds
        RouletteBet.Odd -> result != 0 && result % 2 == 1
        RouletteBet.Even -> result != 0 && result % 2 == 0
        RouletteBet.Number -> result == chosenNumber
    }
    if (!win) return 0
    return if (type == RouletteBet.Number) bet * 36 else bet * 2
}

enum class PokerHand(val label: String, val multiplier: Int) {
    RoyalFlush("Royal Flush", 250),
    StraightFlush("Straight Flush", 50),
    FourKind("Four of a Kind", 25),
    FullHouse("Full House", 9),
    Flush("Flush", 6),
    Straight("Straight", 4),
    ThreeKind("Three of a Kind", 3),
    TwoPair("Two Pair", 2),
    JacksOrBetter("Jacks or Better", 1),
    Nothing("No Win", 0)
}

fun evaluatePoker(hand: List<PlayingCard>): PokerHand {
    val counts = hand.groupingBy { it.rank }.eachCount()
    val values = hand.map {
        when (it.rank) { "A" -> 14; "K" -> 13; "Q" -> 12; "J" -> 11; else -> it.rank.toInt() }
    }.sorted()
    val flush = hand.map { it.suit }.distinct().size == 1
    val straight = values.zipWithNext().all { (a,b) -> b == a + 1 } || values == listOf(2,3,4,5,14)
    val royal = values == listOf(10,11,12,13,14)
    return when {
        flush && straight && royal -> PokerHand.RoyalFlush
        flush && straight -> PokerHand.StraightFlush
        counts.values.any { it == 4 } -> PokerHand.FourKind
        counts.values.sorted() == listOf(2,3) -> PokerHand.FullHouse
        flush -> PokerHand.Flush
        straight -> PokerHand.Straight
        counts.values.any { it == 3 } -> PokerHand.ThreeKind
        counts.values.count { it == 2 } == 2 -> PokerHand.TwoPair
        counts.any { (rank, count) -> count == 2 && rank in setOf("J","Q","K","A") } -> PokerHand.JacksOrBetter
        else -> PokerHand.Nothing
    }
}

fun bankerPayout(bet: Int): Int = (bet * 1.95).roundToInt()
fun randomRouletteNumber(): Int = Random.nextInt(37)
