package com.goldcoincasino.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CasinoColors = darkColorScheme(
    primary = Color(0xFFFF7A00),
    onPrimary = Color(0xFF241A00),
    secondary = Color(0xFFFFA24A),
    background = Color(0xFF090A0C),
    surface = Color(0xFF25282D),
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun GoldCoinCasinoTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = CasinoColors, content = content)
}
