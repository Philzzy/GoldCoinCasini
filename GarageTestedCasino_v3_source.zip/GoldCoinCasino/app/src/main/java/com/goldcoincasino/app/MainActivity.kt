package com.goldcoincasino.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin
import com.goldcoincasino.app.ui.theme.GoldCoinCasinoTheme
import kotlin.random.Random
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoldCoinCasinoTheme { CasinoApp() } }
    }
}

data class CasinoGame(val title: String, val subtitle: String, val icon: String, val screen: Screen)

enum class Screen { Lobby, Slots, Blackjack, Roulette, VideoPoker, Baccarat, Wallet, Profile, Info }

private val casinoGold = Color(0xFFFF7A00) // Garage Tested orange
private val casinoGreen = Color(0xFF090A0C)
private val cardGreen = Color(0xFF15352A)
private val softText = Color(0xFFBFC5C9)
private val steel = Color(0xFF25282D)
private val steelLight = Color(0xFF3A3E45)
private val felt = Color(0xFF0B4A34)
private val hotOrange = Color(0xFFFF8C1A)
private val bets = listOf(50, 100, 250, 500)

@Composable
fun CasinoApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val store = remember { CasinoStore(context.applicationContext) }
    var screen by remember { mutableStateOf(Screen.Lobby) }
    var balance by remember { mutableIntStateOf(store.balance) }
    var canClaimDaily by remember { mutableStateOf(store.canClaimDaily()) }

    fun setBalance(newBalance: Int) {
        balance = newBalance.coerceAtLeast(0)
        store.balance = balance
    }

    fun wager(amount: Int): Boolean {
        if (balance < amount) return false
        setBalance(balance - amount)
        store.recordBet(amount)
        return true
    }

    fun payout(amount: Int) {
        if (amount <= 0) return
        setBalance(balance + amount)
        store.recordWin(amount)
    }

    Scaffold(
        containerColor = casinoGreen,
        bottomBar = {
            if (screen in listOf(Screen.Lobby, Screen.Wallet, Screen.Profile, Screen.Info)) {
                NavigationBar(containerColor = Color(0xFF0B2419)) {
                    NavigationBarItem(screen == Screen.Lobby, { screen = Screen.Lobby }, { Icon(Icons.Default.Home, null) }, label = { Text("Lobby") })
                    NavigationBarItem(screen == Screen.Wallet, { screen = Screen.Wallet }, { Icon(Icons.Default.AccountBalanceWallet, null) }, label = { Text("Wallet") })
                    NavigationBarItem(screen == Screen.Profile, { screen = Screen.Profile }, { Icon(Icons.Default.Person, null) }, label = { Text("Stats") })
                    NavigationBarItem(screen == Screen.Info, { screen = Screen.Info }, { Icon(Icons.Default.Info, null) }, label = { Text("Info") })
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (screen) {
                Screen.Lobby -> LobbyScreen(balance, canClaimDaily, onDailyBonus = {
                    if (store.claimDaily()) {
                        balance = store.balance
                        canClaimDaily = false
                    }
                }, onOpen = { screen = it })
                Screen.Slots -> SlotsScreen(balance, { screen = Screen.Lobby }, ::wager, ::payout)
                Screen.Blackjack -> BlackjackScreen(balance, { screen = Screen.Lobby }, ::wager, ::payout)
                Screen.Roulette -> RouletteScreen(balance, { screen = Screen.Lobby }, ::wager, ::payout)
                Screen.VideoPoker -> VideoPokerScreen(balance, { screen = Screen.Lobby }, ::wager, ::payout)
                Screen.Baccarat -> BaccaratScreen(balance, { screen = Screen.Lobby }, ::wager, ::payout)
                Screen.Wallet -> WalletScreen(balance, canClaimDaily, onClaim = {
                    if (store.claimDaily()) {
                        balance = store.balance
                        canClaimDaily = false
                    }
                })
                Screen.Profile -> ProfileScreen(store, balance, onReset = {
                    store.reset(); balance = store.balance; canClaimDaily = true
                })
                Screen.Info -> InfoScreen()
            }
        }
    }
}

@Composable
private fun Header(balance: Int, compact: Boolean = false) {
    Surface(
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth().background(
            Brush.verticalGradient(listOf(Color(0xFF17191D), Color(0xFF0A0B0D)))
        )
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = if (compact) 10.dp else 17.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(10.dp), color = casinoGold) {
                    Text("GT", color = Color.Black, fontWeight = FontWeight.Black, fontSize = if (compact) 18.sp else 22.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("GARAGE TESTED", color = Color.White, fontWeight = FontWeight.Black, fontSize = if (compact) 18.sp else 22.sp, letterSpacing = 0.8.sp)
                    Text("GOLD COIN CASINO", color = casinoGold, fontWeight = FontWeight.Bold, fontSize = if (compact) 10.sp else 12.sp, letterSpacing = 1.5.sp)
                }
            }
            Surface(shape = RoundedCornerShape(50), color = Color(0xFF1C2024), border = BorderStroke(1.dp, casinoGold.copy(alpha = .55f))) {
                Text("● ${"%,d".format(balance)}", color = Color(0xFFFFB45A), fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp))
            }
        }
    }
}

@Composable
private fun BackHeader(balance: Int, title: String, onBack: () -> Unit) {
    Column {
        Header(balance, compact = true)
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text(title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 23.sp)
        }
    }
}

@Composable
private fun LobbyScreen(balance: Int, dailyReady: Boolean, onDailyBonus: () -> Unit, onOpen: (Screen) -> Unit) {
    val games = listOf(
        CasinoGame("Garage Tested 4096", "6 reels • stacked WILDs • bonus spins", "GT", Screen.Slots),
        CasinoGame("Blackjack", "Garage felt • classic 21", "♠", Screen.Blackjack),
        CasinoGame("European Roulette", "Single-zero precision wheel", "●", Screen.Roulette),
        CasinoGame("Video Poker", "Jacks or Better", "♦", Screen.VideoPoker),
        CasinoGame("Baccarat", "Player • Banker • Tie", "B", Screen.Baccarat)
    )
    LazyColumn(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0D0F12), Color.Black)))) {
        item { Header(balance) }
        item {
            Column(Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
                Text("BUILT IN THE GARAGE. PLAYED FOR FUN.", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
                Text("A Garage Tested play-money casino", color = softText, fontSize = 13.sp)
            }
        }
        item {
            Surface(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), RoundedCornerShape(18.dp), color = steel, border = BorderStroke(1.dp, casinoGold.copy(alpha=.35f))) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(14.dp), color = casinoGold) { Icon(Icons.Default.CardGiftcard, null, tint = Color.Black, modifier = Modifier.padding(10.dp).size(26.dp)) }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("DAILY GARAGE DROP", color = Color.White, fontWeight = FontWeight.Black, fontSize = 17.sp)
                        Text(if (dailyReady) "+2,500 Gold Coins" else "Claimed • come back tomorrow", color = if (dailyReady) casinoGold else softText)
                    }
                    Button(onClick = onDailyBonus, enabled = dailyReady, colors = ButtonDefaults.buttonColors(containerColor = casinoGold, contentColor = Color.Black)) { Text(if (dailyReady) "CLAIM" else "DONE", fontWeight = FontWeight.Black) }
                }
            }
        }
        item { Text("CASINO FLOOR", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp, modifier = Modifier.padding(18.dp, 24.dp, 18.dp, 8.dp)) }
        items(games) { game ->
            Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 7.dp), colors = CardDefaults.cardColors(containerColor = steel), shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Color(0xFF363A40)), onClick = { onOpen(game.screen) }) {
                Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(14.dp), color = if (game.screen == Screen.Roulette) Color(0xFF812020) else Color(0xFF111316), border = BorderStroke(2.dp, casinoGold.copy(alpha=.7f))) {
                        Box(Modifier.size(58.dp), contentAlignment = Alignment.Center) { Text(game.icon, color = casinoGold, fontSize = 28.sp, fontWeight = FontWeight.Black) }
                    }
                    Spacer(Modifier.width(15.dp))
                    Column(Modifier.weight(1f)) { Text(game.title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp); Text(game.subtitle, color = softText, fontSize = 13.sp) }
                    Icon(Icons.Default.ChevronRight, null, tint = casinoGold)
                }
            }
        }
        item { Text("PLAY MONEY ONLY • GOLD COINS HAVE NO CASH VALUE", color = Color(0xFF777D82), fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(20.dp)) }
    }
}

@Composable
private fun BetPicker(bet: Int, enabled: Boolean = true, onBet: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.Center) {
        bets.forEach { amount ->
            FilterChip(selected = bet == amount, enabled = enabled, onClick = { onBet(amount) }, label = { Text("$amount") }, modifier = Modifier.padding(horizontal = 3.dp))
        }
    }
}

enum class SlotSymbol(val title: String) {
    TURBO("TURBO"), WRENCH("WRENCH"), TIRE("TIRE"), ENGINE("ENGINE"),
    COIN("COIN"), BOOST("BOOST"), WILD("WILD"), BONUS("BONUS")
}

private fun weightedSlotSymbol(): SlotSymbol {
    val roll = Random.nextInt(100)
    return when {
        roll < 17 -> SlotSymbol.TURBO
        roll < 34 -> SlotSymbol.WRENCH
        roll < 50 -> SlotSymbol.TIRE
        roll < 65 -> SlotSymbol.ENGINE
        roll < 78 -> SlotSymbol.COIN
        roll < 88 -> SlotSymbol.BOOST
        roll < 96 -> SlotSymbol.WILD
        else -> SlotSymbol.BONUS
    }
}

private fun slotGrid(): List<List<SlotSymbol>> {
    val rows = MutableList(4) { MutableList(6) { weightedSlotSymbol() } }
    // Occasional stacked wild column, similar to modern video slots.
    if (Random.nextInt(100) < 15) {
        val col = Random.nextInt(1, 6)
        repeat(4) { row -> rows[row][col] = SlotSymbol.WILD }
    }
    return rows.map { it.toList() }
}

private data class SlotWin(val payout: Int, val ways: Int, val freeSpins: Int, val label: String)

private fun evaluate4096Ways(grid: List<List<SlotSymbol>>, bet: Int): SlotWin {
    val baseSymbols = SlotSymbol.entries.filter { it != SlotSymbol.WILD && it != SlotSymbol.BONUS }
    val multiplierByLength = mapOf(3 to 1, 4 to 3, 5 to 8, 6 to 20)
    var payout = 0
    var totalWays = 0
    var best = ""

    for (symbol in baseSymbols) {
        var length = 0
        var ways = 1
        for (col in 0 until 6) {
            val count = (0 until 4).count { row ->
                val s = grid[row][col]
                s == symbol || s == SlotSymbol.WILD
            }
            if (count == 0) break
            length++
            ways *= count
        }
        if (length >= 3) {
            val mult = multiplierByLength[length] ?: 0
            // Scale by 16 so 4096-way combinations stay fun without exploding the wallet.
            val award = ((bet.toLong() * mult * ways) / 16L).coerceAtLeast(bet.toLong() / 4L).toInt()
            payout += award
            totalWays += ways
            if (best.isBlank() || length >= 5) best = "$length ${symbol.title} REELS"
        }
    }

    val scatters = grid.sumOf { row -> row.count { it == SlotSymbol.BONUS } }
    var freeSpins = 0
    if (scatters >= 3) {
        freeSpins = when (scatters) { 3 -> 5; 4 -> 8; 5 -> 12; else -> 15 }
        payout += bet * scatters
        best = "BONUS! $freeSpins FREE SPINS"
    }

    return SlotWin(payout, totalWays, freeSpins, best)
}

@Composable
private fun GarageSlotSymbol(symbol: SlotSymbol, modifier: Modifier = Modifier) {
    val accent = when (symbol) {
        SlotSymbol.WILD -> hotOrange
        SlotSymbol.BONUS -> Color(0xFFFFC247)
        SlotSymbol.TURBO -> Color(0xFF7AC7FF)
        SlotSymbol.WRENCH -> Color(0xFFD7DBDF)
        SlotSymbol.TIRE -> Color(0xFFBFC5C9)
        SlotSymbol.ENGINE -> Color(0xFFEF5656)
        SlotSymbol.COIN -> Color(0xFFFFC85A)
        SlotSymbol.BOOST -> Color(0xFF9BF0B1)
    }
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFF101318),
        border = BorderStroke(if (symbol == SlotSymbol.WILD || symbol == SlotSymbol.BONUS) 2.dp else 1.dp, accent.copy(alpha = .9f)),
        shadowElevation = 3.dp
    ) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(accent.copy(alpha=.18f), Color.Transparent))), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                when (symbol) {
                    SlotSymbol.TURBO -> Icon(Icons.Default.Speed, null, tint = accent, modifier = Modifier.size(30.dp))
                    SlotSymbol.WRENCH -> Icon(Icons.Default.Build, null, tint = accent, modifier = Modifier.size(30.dp))
                    SlotSymbol.TIRE -> Canvas(Modifier.size(30.dp)) {
                        drawCircle(accent, radius = size.minDimension * .48f)
                        drawCircle(Color(0xFF101318), radius = size.minDimension * .27f)
                        drawCircle(accent.copy(alpha=.7f), radius = size.minDimension * .12f, style = Stroke(width = 2.5f))
                    }
                    SlotSymbol.ENGINE -> Icon(Icons.Default.Settings, null, tint = accent, modifier = Modifier.size(30.dp))
                    SlotSymbol.COIN -> Icon(Icons.Default.MonetizationOn, null, tint = accent, modifier = Modifier.size(30.dp))
                    SlotSymbol.BOOST -> Icon(Icons.Default.Bolt, null, tint = accent, modifier = Modifier.size(30.dp))
                    SlotSymbol.WILD -> Text("GT", color = Color.White, fontWeight = FontWeight.Black, fontSize = 23.sp)
                    SlotSymbol.BONUS -> Icon(Icons.Default.Star, null, tint = accent, modifier = Modifier.size(30.dp))
                }
                Text(symbol.title, color = if (symbol == SlotSymbol.WILD) Color.White else accent, fontWeight = FontWeight.Black, fontSize = 8.sp, letterSpacing = .3.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun SlotsScreen(balance: Int, onBack: () -> Unit, wager: (Int) -> Boolean, payout: (Int) -> Unit) {
    var grid by remember { mutableStateOf(slotGrid()) }
    var bet by remember { mutableIntStateOf(100) }
    var message by remember { mutableStateOf("4096 WAYS • STACKED WILDS • BONUS SPINS") }
    var isSpinning by remember { mutableStateOf(false) }
    var freeSpins by remember { mutableIntStateOf(0) }
    var lastWin by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()

    fun spin() {
        if (isSpinning) return
        val usingFreeSpin = freeSpins > 0
        if (!usingFreeSpin && !wager(bet)) { message = "NOT ENOUGH GOLD COINS"; return }
        if (usingFreeSpin) freeSpins--
        isSpinning = true
        lastWin = 0
        message = if (usingFreeSpin) "FREE SPIN..." else "BOOSTING REELS..."
        scope.launch {
            repeat(9) {
                grid = slotGrid()
                delay(65)
            }
            val finalGrid = slotGrid()
            grid = finalGrid
            val win = evaluate4096Ways(finalGrid, bet)
            if (win.payout > 0) payout(win.payout)
            freeSpins += win.freeSpins
            lastWin = win.payout
            message = when {
                win.freeSpins > 0 -> "${win.label} • +${"%,d".format(win.payout)}"
                win.payout >= bet * 10 -> "BIG WIN! +${"%,d".format(win.payout)} • ${win.ways} WAYS"
                win.payout > 0 -> "WIN +${"%,d".format(win.payout)} • ${win.ways} WAYS"
                else -> "NO WIN • SPIN AGAIN"
            }
            isSpinning = false
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).background(Color(0xFF050607))) {
        BackHeader(balance, "Garage Tested 4096", onBack)

        Surface(
            Modifier.padding(horizontal = 10.dp).fillMaxWidth(),
            RoundedCornerShape(20.dp),
            color = Color(0xFF171A1F),
            border = BorderStroke(2.dp, hotOrange),
            shadowElevation = 14.dp
        ) {
            Column(Modifier.padding(9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("GARAGE TESTED", color = hotOrange, fontWeight = FontWeight.Black, fontSize = 17.sp, letterSpacing = 1.sp)
                        Text("TURBO SHOP • 4096 WAYS", color = softText, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    }
                    Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFF0A0C0F), border = BorderStroke(1.dp, steelLight)) {
                        Text(if (freeSpins > 0) "FREE $freeSpins" else "4096 WAYS", color = if (freeSpins > 0) hotOrange else Color.White, fontWeight = FontWeight.Black, modifier = Modifier.padding(10.dp, 6.dp))
                    }
                }
                Spacer(Modifier.height(8.dp))
                Surface(shape = RoundedCornerShape(12.dp), color = Color.Black, border = BorderStroke(2.dp, steelLight)) {
                    Column(Modifier.padding(5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        repeat(4) { row ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                repeat(6) { col ->
                                    GarageSlotSymbol(grid[row][col], Modifier.weight(1f).height(73.dp))
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(message, color = if (lastWin > 0) Color(0xFFFFD066) else Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, minLines = 1)
            }
        }

        Spacer(Modifier.height(10.dp))
        Text("TOTAL BET", color = softText, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
        BetPicker(bet, enabled = !isSpinning && freeSpins == 0, onBet = { bet = it })

        Button(
            enabled = !isSpinning,
            onClick = { spin() },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 5.dp).height(66.dp),
            colors = ButtonDefaults.buttonColors(containerColor = hotOrange, contentColor = Color(0xFF17120C))
        ) {
            Icon(if (isSpinning) Icons.Default.Sync else Icons.Default.Casino, null, modifier = Modifier.size(27.dp))
            Spacer(Modifier.width(10.dp))
            Text(
                when {
                    isSpinning -> "SPINNING..."
                    freeSpins > 0 -> "FREE SPIN • $freeSpins LEFT"
                    else -> "SPIN • ${"%,d".format(bet)} COINS"
                },
                fontWeight = FontWeight.Black, fontSize = 18.sp
            )
        }

        Surface(Modifier.padding(14.dp).fillMaxWidth(), RoundedCornerShape(16.dp), color = steel) {
            Column(Modifier.padding(14.dp)) {
                Text("FEATURES", color = hotOrange, fontWeight = FontWeight.Black, fontSize = 16.sp)
                Text("• 6 reels × 4 rows = 4,096 ways to win", color = softText, modifier = Modifier.padding(top=6.dp))
                Text("• WILD substitutes on left-to-right ways", color = softText)
                Text("• Random stacked WILD reel", color = softText)
                Text("• 3+ BONUS symbols trigger free spins", color = softText)
                Text("• Gold Coins are play money only", color = Color(0xFF8F969B), fontSize = 11.sp, modifier = Modifier.padding(top=8.dp))
            }
        }
        Spacer(Modifier.height(90.dp))
    }
}

@Composable
private fun BlackjackScreen(balance: Int, onBack: () -> Unit, wager: (Int) -> Boolean, payout: (Int) -> Unit) {
    var bet by remember { mutableIntStateOf(100) }
    var deck by remember { mutableStateOf(shuffledDeck()) }
    var player by remember { mutableStateOf(emptyList<PlayingCard>()) }
    var dealer by remember { mutableStateOf(emptyList<PlayingCard>()) }
    var active by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Place a bet to deal") }

    fun finishRound() {
        var d = dealer.toMutableList()
        while (blackjackScore(d) < 17) d.add(deck.removeAt(0))
        dealer = d
        val pScore = blackjackScore(player); val dScore = blackjackScore(d)
        val result = when {
            pScore > 21 -> 0
            dScore > 21 || pScore > dScore -> bet * 2
            pScore == dScore -> bet
            else -> 0
        }
        payout(result)
        message = when { result == bet * 2 -> "You win! +${result - bet}"; result == bet -> "Push — bet returned"; else -> "Dealer wins" }
        active = false
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        BackHeader(balance, "Blackjack", onBack)
        HandPanel("Dealer", dealer, if (active && dealer.isNotEmpty()) "${dealer.first().display}  🂠" else dealer.joinToString("  ") { it.display }, if (!active && dealer.isNotEmpty()) blackjackScore(dealer).toString() else "")
        HandPanel("You", player, player.joinToString("  ") { it.display }, if (player.isNotEmpty()) blackjackScore(player).toString() else "")
        Text(message, color = casinoGold, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(12.dp))
        BetPicker(bet, enabled = !active, onBet = { bet = it })
        if (!active) {
            Button(onClick = {
                if (!wager(bet)) { message = "Not enough Gold Coins"; return@Button }
                deck = shuffledDeck()
                player = listOf(deck.removeAt(0), deck.removeAt(0)); dealer = listOf(deck.removeAt(0), deck.removeAt(0)); active = true
                message = "Hit or stand"
                if (blackjackScore(player) == 21) {
                    val blackjackPay = bet + (bet * 3 / 2)
                    payout(blackjackPay); message = "Blackjack! +${blackjackPay - bet}"; active = false
                }
            }, modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp)) { Text("DEAL • $bet COINS") }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 28.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = {
                    val p = player + deck.removeAt(0); player = p
                    if (blackjackScore(p) > 21) { message = "Bust — dealer wins"; active = false }
                    else if (blackjackScore(p) == 21) finishRound()
                }, modifier = Modifier.weight(1f)) { Text("HIT") }
                Button(onClick = { finishRound() }, modifier = Modifier.weight(1f)) { Text("STAND") }
            }
        }
        RulesText("Blackjack pays 3:2. Dealer stands on 17. Regular wins pay 1:1; pushes return the bet.")
    }
}

@Composable
private fun RouletteScreen(balance: Int, onBack: () -> Unit, wager: (Int) -> Boolean, payout: (Int) -> Unit) {
    var bet by remember { mutableIntStateOf(100) }
    var type by remember { mutableStateOf(RouletteBet.Red) }
    var number by remember { mutableIntStateOf(7) }
    var result by remember { mutableStateOf<Int?>(null) }
    var message by remember { mutableStateOf("Choose a wager and spin") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        BackHeader(balance, "European Roulette", onBack)
        RouletteWheel(result)
        Text(message, color = casinoGold, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp))
        Text("BET TYPE", color = softText, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        RouletteBet.entries.forEach { option ->
            Row(Modifier.fillMaxWidth().clickable { type = option }.padding(horizontal = 30.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = type == option, onClick = { type = option }); Text(option.label, color = Color.White)
            }
        }
        if (type == RouletteBet.Number) {
            Column(Modifier.padding(horizontal = 14.dp)) {
                Surface(modifier = Modifier.fillMaxWidth().padding(bottom=4.dp).clickable { number = 0 }, shape=RoundedCornerShape(6.dp), color = if (number==0) casinoGold else Color(0xFF087A43), border=BorderStroke(2.dp, if(number==0) Color.White else Color.Transparent)) { Text("0", color=Color.White, fontWeight=FontWeight.Black, textAlign=TextAlign.Center, modifier=Modifier.padding(8.dp)) }
                for (row in 0 until 12) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (col in 1..3) {
                            val n = row*3 + col
                            val bg = if (n in rouletteReds) Color(0xFF9E2424) else Color(0xFF171717)
                            Surface(modifier = Modifier.weight(1f).clickable { number=n }, shape=RoundedCornerShape(5.dp), color=bg, border=BorderStroke(if(number==n) 2.dp else 1.dp, if(number==n) casinoGold else Color(0xFF4A4A4A))) { Text("$n", color=Color.White, fontWeight=FontWeight.Black, textAlign=TextAlign.Center, modifier=Modifier.padding(vertical=7.dp)) }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { number = (number - 1).coerceAtLeast(0) }) { Icon(Icons.Default.Remove, null) }
                Text("$number", color = casinoGold, fontWeight = FontWeight.Black, fontSize = 28.sp, modifier = Modifier.padding(horizontal = 20.dp))
                IconButton(onClick = { number = (number + 1).coerceAtMost(36) }) { Icon(Icons.Default.Add, null) }
            }
        }
        BetPicker(bet, onBet = { bet = it })
        Button(onClick = {
            if (!wager(bet)) { message = "Not enough Gold Coins"; return@Button }
            val r = randomRouletteNumber(); result = r
            val win = roulettePayout(type, number, r, bet); payout(win)
            message = if (win > 0) "Winner! Payout ${"%,d".format(win)}" else "No win this spin"
        }, modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp)) { Text("SPIN • $bet COINS") }
        RulesText("Single-zero European wheel. Red/Black/Odd/Even pay 1:1. Straight-up number pays 35:1 plus the returned stake.")
    }
}

@Composable
private fun VideoPokerScreen(balance: Int, onBack: () -> Unit, wager: (Int) -> Boolean, payout: (Int) -> Unit) {
    var bet by remember { mutableIntStateOf(100) }
    var deck by remember { mutableStateOf(shuffledDeck()) }
    var hand by remember { mutableStateOf(emptyList<PlayingCard>()) }
    var held by remember { mutableStateOf(setOf<Int>()) }
    var drawing by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Deal five cards") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        BackHeader(balance, "Video Poker", onBack)
        Text(message, color = casinoGold, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.Center)
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            hand.forEachIndexed { index, card ->
                PlayingCardFace(card, held = index in held, onClick = if (drawing) ({ held = if (index in held) held - index else held + index }) else null)
            }
        }
        Spacer(Modifier.height(12.dp)); BetPicker(bet, enabled = !drawing, onBet = { bet = it })
        Button(onClick = {
            if (!drawing) {
                if (!wager(bet)) { message = "Not enough Gold Coins"; return@Button }
                deck = shuffledDeck(); hand = List(5) { deck.removeAt(0) }; held = emptySet(); drawing = true; message = "Tap cards to HOLD, then draw"
            } else {
                hand = hand.mapIndexed { index, card -> if (index in held) card else deck.removeAt(0) }
                val result = evaluatePoker(hand); val win = bet * result.multiplier; payout(win)
                message = if (win > 0) "${result.label}! Payout ${"%,d".format(win)}" else result.label
                drawing = false; held = emptySet()
            }
        }, modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp)) { Text(if (drawing) "DRAW" else "DEAL • $bet COINS") }
        Paytable(PokerHand.entries.filter { it.multiplier > 0 }.map { it.label to "${it.multiplier}×" })
    }
}

@Composable
private fun BaccaratScreen(balance: Int, onBack: () -> Unit, wager: (Int) -> Boolean, payout: (Int) -> Unit) {
    var bet by remember { mutableIntStateOf(100) }
    var choice by remember { mutableStateOf("Player") }
    var round by remember { mutableStateOf<BaccaratRound?>(null) }
    var message by remember { mutableStateOf("Choose Player, Banker, or Tie") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        BackHeader(balance, "Baccarat", onBack)
        val current = round
        HandPanel("Banker", current?.banker ?: emptyList(), current?.banker?.joinToString("  ") { it.display } ?: "—", current?.let { baccaratScore(it.banker).toString() } ?: "")
        HandPanel("Player", current?.player ?: emptyList(), current?.player?.joinToString("  ") { it.display } ?: "—", current?.let { baccaratScore(it.player).toString() } ?: "")
        Text(message, color = casinoGold, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth().padding(10.dp), textAlign = TextAlign.Center)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            listOf("Player", "Banker", "Tie").forEach { option -> FilterChip(choice == option, { choice = option }, { Text(option) }, modifier = Modifier.padding(4.dp)) }
        }
        BetPicker(bet, onBet = { bet = it })
        Button(onClick = {
            if (!wager(bet)) { message = "Not enough Gold Coins"; return@Button }
            val r = dealBaccarat(); round = r
            val win = when {
                choice != r.winner -> 0
                choice == "Player" -> bet * 2
                choice == "Banker" -> bankerPayout(bet)
                else -> bet * 9
            }
            payout(win); message = "${r.winner} wins" + if (win > 0) " • payout ${"%,d".format(win)}" else ""
        }, modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp)) { Text("DEAL • $bet COINS") }
        RulesText("Player pays 1:1. Banker pays 0.95:1 plus stake (5% commission). Tie pays 8:1 plus stake. Standard third-card drawing rules are applied.")
    }
}

@Composable
private fun HandPanel(title: String, hand: List<PlayingCard>, cardsText: String, scoreText: String) {
    Surface(Modifier.padding(horizontal = 18.dp, vertical = 7.dp).fillMaxWidth(), RoundedCornerShape(22.dp), color = felt, border = BorderStroke(2.dp, Color(0xFF1E6A4E))) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title.uppercase(), color = Color(0xFFD7E6DF), fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                if (scoreText.isNotEmpty()) Surface(shape = RoundedCornerShape(20.dp), color = Color.Black.copy(alpha=.35f)) { Text("$scoreText", color = casinoGold, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal=10.dp, vertical=4.dp)) }
            }
            Spacer(Modifier.height(12.dp))
            if (hand.isEmpty()) { Text("—", color = Color.White, fontSize = 28.sp) }
            else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val hideHole = cardsText.contains("🂠") && hand.size > 1
                    hand.forEachIndexed { index, card ->
                        if (hideHole && index == 1) PlayingCardBack(compact = true) else PlayingCardFace(card, compact = true)
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayingCardFace(card: PlayingCard, compact: Boolean = false, held: Boolean = false, onClick: (() -> Unit)? = null) {
    val red = card.suit == "♥" || card.suit == "♦"
    Surface(
        modifier = Modifier.then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        shape = RoundedCornerShape(9.dp),
        color = if (held) Color(0xFFFFE0A8) else Color(0xFFF7F4EA),
        border = BorderStroke(if (held) 3.dp else 1.dp, if (held) casinoGold else Color(0xFFB7B7B7)),
        shadowElevation = 5.dp
    ) {
        Box(Modifier.width(if (compact) 58.dp else 62.dp).height(if (compact) 82.dp else 92.dp).padding(6.dp)) {
            Column(Modifier.align(Alignment.TopStart)) { Text(card.rank, color = if (red) Color(0xFFB11B1B) else Color(0xFF111111), fontWeight = FontWeight.Black, fontSize = 17.sp); Text(card.suit, color = if (red) Color(0xFFB11B1B) else Color.Black, fontSize = 16.sp) }
            Text(card.suit, color = if (red) Color(0xFFB11B1B) else Color.Black, fontSize = if (compact) 27.sp else 31.sp, modifier = Modifier.align(Alignment.Center))
            if (held) Text("HOLD", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 9.sp, modifier = Modifier.align(Alignment.BottomCenter))
        }
    }
}


@Composable
private fun PlayingCardBack(compact: Boolean = false) {
    Surface(shape = RoundedCornerShape(9.dp), color = Color(0xFF17191D), border = BorderStroke(2.dp, casinoGold), shadowElevation = 5.dp) {
        Box(Modifier.width(if (compact) 58.dp else 62.dp).height(if (compact) 82.dp else 92.dp).padding(6.dp), contentAlignment = Alignment.Center) {
            Surface(shape = RoundedCornerShape(6.dp), color = Color(0xFF24272C), border = BorderStroke(1.dp, casinoGold.copy(alpha=.65f))) {
                Column(Modifier.fillMaxSize().padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("GT", color = casinoGold, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    Text("GARAGE", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun RouletteWheel(result: Int?) {
    val redNumbers = rouletteReds
    Box(Modifier.fillMaxWidth().height(250.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(230.dp)) {
            val c = center; val radius = size.minDimension / 2f
            drawCircle(Color(0xFF17191D), radius)
            drawCircle(casinoGold, radius, style = Stroke(6f))
            val slices = 37
            repeat(slices) { i ->
                val start = -90f + i * (360f / slices)
                val color = when { i == 0 -> Color(0xFF087A43); i in redNumbers -> Color(0xFF9E2424); else -> Color(0xFF171717) }
                drawArc(color, start, 360f/slices, true, topLeft = Offset(c.x-radius+10, c.y-radius+10), size = Size((radius-10)*2,(radius-10)*2))
            }
            drawCircle(Color(0xFF2A2D31), radius*.43f)
            drawCircle(casinoGold, radius*.43f, style = Stroke(4f))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(result?.toString() ?: "0", color = Color.White, fontWeight = FontWeight.Black, fontSize = 48.sp); Text("GARAGE TESTED", color = casinoGold, fontSize = 10.sp, fontWeight = FontWeight.Black) }
    }
}

@Composable
private fun Paytable(rows: List<Pair<String,String>>) {
    Surface(Modifier.padding(18.dp).fillMaxWidth(), RoundedCornerShape(16.dp), color = Color(0xFF0D241A)) {
        Column(Modifier.padding(14.dp)) {
            Text("PAYTABLE", color = casinoGold, fontWeight = FontWeight.Bold)
            rows.forEach { (name, pay) -> Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(name, color = softText); Text(pay, color = Color.White) } }
        }
    }
}

@Composable
private fun RulesText(text: String) {
    Text(text, color = Color(0xFF90AF9C), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(18.dp))
}

@Composable
private fun WalletScreen(balance: Int, dailyReady: Boolean, onClaim: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(balance)
        Text("Wallet", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 28.sp, modifier = Modifier.padding(horizontal = 18.dp))
        Surface(Modifier.padding(18.dp).fillMaxWidth(), RoundedCornerShape(20.dp), color = cardGreen) {
            Column(Modifier.padding(22.dp)) {
                Text("Gold Coin Balance", color = softText); Text("🪙 ${"%,d".format(balance)}", color = Color(0xFFFFD36B), fontWeight = FontWeight.Black, fontSize = 34.sp)
                Spacer(Modifier.height(20.dp)); Button(onClick = onClaim, enabled = dailyReady, modifier = Modifier.fillMaxWidth()) { Text(if (dailyReady) "CLAIM 2,500 DAILY COINS" else "DAILY BONUS CLAIMED") }
            }
        }
        Surface(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), RoundedCornerShape(20.dp), color = Color(0xFF132A20)) {
            Column(Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Lock, null, tint = casinoGold); Spacer(Modifier.width(8.dp)); Text("Real Money Mode", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp) }
                Spacer(Modifier.height(8.dp)); Text("Not available in this release. Gold Coins cannot be purchased for cash, redeemed, transferred, or converted to real-world value.", color = softText)
            }
        }
    }
}

@Composable
private fun ProfileScreen(store: CasinoStore, balance: Int, onReset: () -> Unit) {
    var confirmReset by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(balance)
        Text("Player Stats", color = Color.White, fontWeight = FontWeight.Black, fontSize = 28.sp, modifier = Modifier.padding(horizontal = 18.dp))
        StatCard("Games played", "${store.gamesPlayed}")
        StatCard("Total wagered", "🪙 ${"%,d".format(store.totalWagered)}")
        StatCard("Total payouts", "🪙 ${"%,d".format(store.totalWon)}")
        StatCard("Biggest payout", "🪙 ${"%,d".format(store.biggestWin)}")
        OutlinedButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth().padding(18.dp)) { Text("RESET LOCAL PROGRESS") }
    }
    if (confirmReset) AlertDialog(onDismissRequest = { confirmReset = false }, title = { Text("Reset progress?") }, text = { Text("This restores the starting 10,000 Gold Coins and clears local stats.") }, confirmButton = { TextButton(onClick = { onReset(); confirmReset = false }) { Text("Reset") } }, dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } })
}

@Composable
private fun StatCard(label: String, value: String) {
    Surface(Modifier.padding(horizontal = 18.dp, vertical = 5.dp).fillMaxWidth(), RoundedCornerShape(16.dp), color = cardGreen) {
        Row(Modifier.padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(label, color = softText); Text(value, color = Color.White, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun InfoScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Spacer(Modifier.height(10.dp)); Text("About Garage Tested Casino", color = Color.White, fontWeight = FontWeight.Black, fontSize = 28.sp)
        Spacer(Modifier.height(14.dp)); Text("A Garage Tested multi-game social casino using virtual Gold Coins for entertainment only.", color = softText, fontSize = 17.sp)
        InfoSection("Play-money only", "Gold Coins have no cash value. They cannot be redeemed, transferred, sold, or exchanged for prizes or money.")
        InfoSection("Responsible play", "Set personal time limits, take regular breaks, and treat every game as entertainment. Outcomes are randomized and there is no strategy that guarantees a win.")
        InfoSection("Privacy", "This release stores balance and statistics only on this device using Android local preferences. It does not require an account, contacts, location, or internet access.")
        InfoSection("Future real-money mode", "A future real-money product would be a separate regulated feature requiring jurisdiction-specific licensing, age and identity checks, geolocation, responsible-gambling controls, secure payments, auditing, and store approval before activation.")
        InfoSection("Version", "1.0.0 • Play-money release")
    }
}

@Composable
private fun InfoSection(title: String, body: String) {
    Surface(Modifier.padding(top = 14.dp).fillMaxWidth(), RoundedCornerShape(16.dp), color = cardGreen) {
        Column(Modifier.padding(18.dp)) { Text(title, color = casinoGold, fontWeight = FontWeight.Bold, fontSize = 18.sp); Spacer(Modifier.height(5.dp)); Text(body, color = softText) }
    }
}
