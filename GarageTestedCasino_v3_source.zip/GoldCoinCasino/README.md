# Garage Tested Gold Coin Casino v2.0

Play-money Android casino with Garage Tested visual branding.

## v2 visual overhaul
- Garage Tested orange / charcoal / brushed-steel styling
- Rebuilt lobby with Garage Tested branding and premium game cards
- Blackjack rendered with real card-style faces and a hidden dealer hole card
- European Roulette rendered with a roulette wheel and selectable 0–36 number table
- Slots rebuilt as a metal-framed casino machine
- Video Poker uses full card-style faces with HOLD highlighting
- Baccarat uses the same card-table presentation
- Persistent local Gold Coin wallet, daily bonus and stats preserved

## Games
- Lucky 7 Slots
- Blackjack
- European Roulette
- Jacks or Better Video Poker
- Baccarat

## Play-money only
Gold Coins have no cash value and cannot be redeemed, sold, transferred, or exchanged for prizes or money.
