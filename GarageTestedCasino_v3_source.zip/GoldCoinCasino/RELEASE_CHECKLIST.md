# Gold Coin Casino v1.0 Release Checklist

## Complete in source
- [x] Five playable games
- [x] Persistent play-money wallet
- [x] Daily reward
- [x] Persistent player statistics
- [x] Responsible-play disclosure
- [x] Local privacy disclosure
- [x] No internet or payment permissions
- [x] Real-money mode disabled
- [x] App icon resource
- [x] Version 1.0.0 / versionCode 1
- [x] Core game-logic checks

## Requires app owner / Android Studio
- [ ] Choose final application ID before first public Play release (changing it later creates a different app)
- [ ] Create and securely store release signing key
- [ ] Build signed Android App Bundle (.aab)
- [ ] Test on at least one physical phone and representative emulators
- [ ] Provide final 512×512 store icon, feature graphic, screenshots, short description and full description
- [ ] Host the privacy policy at a public URL if the chosen store requires one
- [ ] Complete Google Play content rating, Data safety, ads and app-access declarations
- [ ] Complete developer account / identity / testing requirements

## Future real-money product — separate compliance project
- [ ] Jurisdiction-specific gambling licenses and legal review
- [ ] Age/identity verification
- [ ] Geolocation and jurisdiction controls
- [ ] Responsible gambling limits and self-exclusion
- [ ] Server-authoritative wallet and immutable ledger
- [ ] Certified/audited RNG and game math as required
- [ ] Secure deposits/withdrawals and AML/KYC controls
- [ ] Gambling-specific store approval and country/state availability controls
