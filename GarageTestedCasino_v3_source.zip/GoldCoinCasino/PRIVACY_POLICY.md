# Gold Coin Casino Privacy Policy

**Effective date:** August 22, 2026

Gold Coin Casino is a play-money entertainment application. It does not require an account and does not collect or transmit personal information in this release.

The app stores only gameplay information locally on the user's device, including virtual Gold Coin balance, daily reward status, games played, virtual wager totals, payout totals, and biggest virtual payout. This information is used only to preserve gameplay progress.

Gold Coin Casino does not request or use location, contacts, camera, microphone, advertising identifiers, payment information, or real-money gambling information. The app has no internet permission in this release.

Users may erase locally stored gameplay information at any time using the Reset Local Progress control in the app or by clearing the app's storage through Android settings.

Gold Coins have no cash value and cannot be redeemed, transferred, sold, or exchanged for prizes or money.

If future versions add online accounts, analytics, advertising, purchases, or regulated wagering, this policy must be updated before those features are released.
