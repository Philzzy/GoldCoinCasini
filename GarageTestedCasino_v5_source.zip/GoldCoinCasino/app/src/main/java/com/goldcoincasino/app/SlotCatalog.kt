package com.goldcoincasino.app

data class SlotGameConfig(
    val id: Int,
    val title: String,
    val category: String,
    val subtitle: String,
    val reels: Int,
    val rows: Int,
    val volatility: Int,
    val primary: Long,
    val secondary: Long,
    val feature: String,
    val jackpot: Int,
    val symbols: List<String>
) {
    val ways: Int get() {
        var total = 1
        repeat(reels) { total *= rows }
        return total
    }
}

private data class SlotTheme(
    val category: String,
    val names: List<String>,
    val colors: List<Pair<Long, Long>>,
    val symbols: List<String>
)

private val slotThemes = listOf(
    SlotTheme("Garage Originals", listOf(
        "Garage Tested 4096", "Wrench & Win", "Toolbox Thunder", "Mechanic's Millions", "Parts Counter Gold",
        "Shop Night Riches", "Orange Line Jackpot", "Lift Bay Bonus", "Grease & Glory", "Built Not Bought"
    ), listOf(0xFFFF6A00 to 0xFF3A220D, 0xFFFF8D24 to 0xFF2A2D32, 0xFFE6A23C to 0xFF25282D),
        listOf("WRENCH", "SOCKET", "LIFT", "TOOLBOX", "GT COIN", "ENGINE")),
    SlotTheme("Cars & Racing", listOf(
        "Boosted BMW", "Turbo Jackpot", "Burnout Bucks", "Dyno Day", "Redline Riches",
        "Quarter Mile Cash", "Apex Fortune", "Boost Gauge Gold", "Pit Lane Payday", "Street Machine"
    ), listOf(0xFFEF5B2A to 0xFF30110A, 0xFF25B6FF to 0xFF071E31, 0xFFFFB020 to 0xFF2B1602),
        listOf("TURBO", "WHEEL", "BOOST", "FLAG", "DYNO", "ENGINE")),
    SlotTheme("Tow Truck", listOf(
        "Tow Truck Riches", "Flatbed Fortune", "Hook & Book", "Recovery Road", "Rollback Gold",
        "Midnight Tow", "Winch Line Wilds", "Heavy Duty Haul", "Dispatch Jackpot", "Roadside Riches"
    ), listOf(0xFFFF7A00 to 0xFF33210D, 0xFFF1C40F to 0xFF302705, 0xFF4AA3FF to 0xFF0A2032),
        listOf("FLATBED", "HOOK", "WINCH", "CONE", "CHAIN", "LIGHTBAR")),
    SlotTheme("Classic Slots", listOf(
        "Triple 7 Garage", "Orange Bar Deluxe", "Cherry Chrome", "Lucky Bells", "Golden Horseshoe",
        "Hot Sevens", "Double Diamond GT", "Classic Cash", "Big Bar Bonus", "Lucky Garage 5"
    ), listOf(0xFFE53935 to 0xFF300606, 0xFFFFC107 to 0xFF322500, 0xFF8E44AD to 0xFF210A27),
        listOf("SEVEN", "BAR", "CHERRY", "BELL", "DIAMOND", "COIN")),
    SlotTheme("Vegas", listOf(
        "Neon Strip", "High Roller Nights", "Vegas Vault", "Casino Royale Gold", "Diamond Lounge",
        "Midnight Millions", "Jackpot Boulevard", "VIP Fortune", "Lucky Lights", "Golden Strip"
    ), listOf(0xFFFF2D95 to 0xFF250018, 0xFF8C5CFF to 0xFF14072C, 0xFFFFC64D to 0xFF261A00),
        listOf("CHIP", "DICE", "CARD", "DIAMOND", "CROWN", "JACKPOT")),
    SlotTheme("Adventure", listOf(
        "Treasure Run", "Lost Garage Gold", "Desert Vault", "Jungle Jackpot", "Temple Torque",
        "Arctic Fortune", "Island Riches", "Canyon Cash", "Explorer Wilds", "Hidden Gold"
    ), listOf(0xFF00B894 to 0xFF03261F, 0xFFD98C2B to 0xFF2A1705, 0xFF3F8CFF to 0xFF071C3A),
        listOf("MAP", "COMPASS", "CHEST", "GEM", "TORCH", "GOLD")),
    SlotTheme("Fantasy", listOf(
        "Dragon Dyno", "Wizard's Workshop", "Phoenix Boost", "Kingdom of Torque", "Mystic Garage",
        "Rune Riches", "Crystal Wilds", "Knight Shift", "Fire Forge", "Enchanted Jackpot"
    ), listOf(0xFF9B59B6 to 0xFF19071E, 0xFFFF5A36 to 0xFF301008, 0xFF4DD0E1 to 0xFF06272A),
        listOf("DRAGON", "RUNE", "CRYSTAL", "CROWN", "FIRE", "ORB")),
    SlotTheme("Animals", listOf(
        "Wolf Pack Wins", "Eagle Eye Gold", "Bear Market Bonus", "Wild Stallion", "Panther Payday",
        "Buffalo Boost", "Tiger Torque", "Lion's Share", "Shark Tank Gold", "Raven Riches"
    ), listOf(0xFF5DADE2 to 0xFF071D2B, 0xFFE67E22 to 0xFF2B1404, 0xFF58D68D to 0xFF082517),
        listOf("WOLF", "EAGLE", "PAW", "MOUNTAIN", "MOON", "GOLD")),
    SlotTheme("High Limit", listOf(
        "GT High Limit", "Million Coin Garage", "Diamond Torque", "Black Card Jackpot", "Executive Bay",
        "Platinum Pit", "Big Money Boost", "Premium Parts", "Gold Standard", "Ultra High Roller"
    ), listOf(0xFFFFD54F to 0xFF211A02, 0xFFE0E0E0 to 0xFF252525, 0xFFB388FF to 0xFF17072C),
        listOf("DIAMOND", "PLATINUM", "CROWN", "GT", "VAULT", "GOLD")),
    SlotTheme("Night Shift", listOf(
        "Graveyard Garage", "Midnight Mechanic", "After Hours", "Neon Wrench", "2AM Tow",
        "Night Owl Riches", "Dark Shop Wilds", "Late Shift Loot", "Moonlight Motors", "Blacktop Bonus"
    ), listOf(0xFF536DFE to 0xFF090C2A, 0xFF00E5FF to 0xFF00242A, 0xFFFF4081 to 0xFF280012),
        listOf("MOON", "NEON", "WRENCH", "LIGHT", "COFFEE", "COIN")),
    SlotTheme("Off Road", listOf(
        "Mud Money", "4x4 Fortune", "Trail Boss", "Rock Crawler Riches", "Jeep Jackpot",
        "Dirt Road Gold", "Winch Woods", "Monster Tire", "Trailhead Treasure", "Backcountry Bonus"
    ), listOf(0xFF8D6E63 to 0xFF241713, 0xFF7CB342 to 0xFF102305, 0xFFFFA000 to 0xFF291900),
        listOf("TIRE", "MUD", "TRAIL", "WINCH", "MOUNTAIN", "4X4")),
    SlotTheme("Shop Legends", listOf(
        "Master Tech", "Old School Garage", "Ratchet Riches", "Diagnostic Gold", "Scan Tool Wilds",
        "Torque Spec", "Breaker Bar Bonus", "Air Tool Payday", "Service Bay 7s", "Garage Legends"
    ), listOf(0xFFFF7043 to 0xFF2A0D05, 0xFF78909C to 0xFF101619, 0xFFFFCA28 to 0xFF251C01),
        listOf("RATCHET", "SCAN", "TORQUE", "AIR", "GAUGE", "GT"))
)

val slotCatalog: List<SlotGameConfig> = buildList {
    var id = 1
    slotThemes.forEachIndexed { themeIndex, theme ->
        theme.names.forEachIndexed { index, name ->
            val color = theme.colors[index % theme.colors.size]
            val reels = if ((index + themeIndex) % 3 == 0) 6 else 5
            val rows = if ((index + themeIndex) % 4 == 0) 4 else 3
            val volatility = 1 + ((index * 2 + themeIndex) % 5)
            val features = listOf("STACKED WILDS", "FREE SPINS", "EXPANDING WILDS", "MULTIPLIER WILDS", "RESPINS", "PICK BONUS")
            val feature = features[(index + themeIndex) % features.size]
            val jackpot = 25000 + ((id * 7919) % 475000)
            add(SlotGameConfig(
                id = id++, title = name, category = theme.category,
                subtitle = "${rows}×${reels} • ${feature.lowercase()} • ${if (volatility >= 4) "high" else if (volatility <= 2) "smooth" else "medium"} volatility",
                reels = reels, rows = rows, volatility = volatility,
                primary = color.first, secondary = color.second,
                feature = feature, jackpot = jackpot,
                symbols = theme.symbols
            ))
        }
    }
}

val slotCategories: List<String> = listOf("All") + slotThemes.map { it.category }
