package com.goldcoincasino.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin
import com.goldcoincasino.app.ui.theme.GoldCoinCasinoTheme
import kotlin.random.Random
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GoldCoinCasinoTheme { CasinoApp() } }
    }
}

data class CasinoGame(val title: String, val subtitle: String, val icon: String, val screen: Screen)

enum class Screen { Lobby, Slots, SlotGame, Blackjack, Roulette, VideoPoker, Baccarat, Wallet, Profile, Info }

enum class CurrencyMode { GOLD, SWEEP }

private fun moneyText(amount: Int, mode: CurrencyMode): String =
    if (mode == CurrencyMode.GOLD) "${"%,d".format(amount)} GC"
    else "SC %.2f".format(amount / 100.0)

private val casinoGold = Color(0xFFFF7A00) // Garage Tested orange
private val casinoGreen = Color(0xFF090A0C)
private val cardGreen = Color(0xFF15352A)
private val softText = Color(0xFFBFC5C9)
private val steel = Color(0xFF25282D)
private val steelLight = Color(0xFF3A3E45)
private val felt = Color(0xFF0B4A34)
private val hotOrange = Color(0xFFFF8C1A)
private val bets = listOf(50, 100, 250, 500)

@Composable
fun CasinoApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val store = remember { CasinoStore(context.applicationContext) }
    var screen by remember { mutableStateOf(Screen.Lobby) }
    var selectedSlot by remember { mutableStateOf(slotCatalog.first()) }
    var goldBalance by remember { mutableIntStateOf(store.balance) }
    var sweepBalance by remember { mutableIntStateOf(store.sweepBalance) }
    var currencyMode by remember { mutableStateOf(CurrencyMode.GOLD) }
    var canClaimDaily by remember { mutableStateOf(store.canClaimDaily()) }

    val activeBalance = if (currencyMode == CurrencyMode.GOLD) goldBalance else sweepBalance

    fun setActiveBalance(newBalance: Int) {
        if (currencyMode == CurrencyMode.GOLD) {
            goldBalance = newBalance.coerceAtLeast(0); store.balance = goldBalance
        } else {
            sweepBalance = newBalance.coerceAtLeast(0); store.sweepBalance = sweepBalance
        }
    }

    fun wager(amount: Int): Boolean {
        val current = if (currencyMode == CurrencyMode.GOLD) goldBalance else sweepBalance
        if (current < amount) return false
        setActiveBalance(current - amount)
        store.recordBet(amount)
        return true
    }

    fun payout(amount: Int) {
        if (amount <= 0) return
        val current = if (currencyMode == CurrencyMode.GOLD) goldBalance else sweepBalance
        setActiveBalance(current + amount)
        store.recordWin(amount)
    }

    Scaffold(
        containerColor = casinoGreen,
        bottomBar = {
            if (screen in listOf(Screen.Lobby, Screen.Wallet, Screen.Profile, Screen.Info)) {
                NavigationBar(containerColor = Color(0xFF0B0D10)) {
                    NavigationBarItem(screen == Screen.Lobby, { screen = Screen.Lobby }, { Icon(Icons.Default.Home, null) }, label = { Text("Lobby") })
                    NavigationBarItem(screen == Screen.Wallet, { screen = Screen.Wallet }, { Icon(Icons.Default.AccountBalanceWallet, null) }, label = { Text("Wallet") })
                    NavigationBarItem(screen == Screen.Profile, { screen = Screen.Profile }, { Icon(Icons.Default.Person, null) }, label = { Text("Stats") })
                    NavigationBarItem(screen == Screen.Info, { screen = Screen.Info }, { Icon(Icons.Default.Info, null) }, label = { Text("Info") })
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (screen) {
                Screen.Lobby -> LobbyScreen(activeBalance, currencyMode, canClaimDaily, onCurrency = { currencyMode = it }, onDailyBonus = {
                    if (store.claimDaily()) {
                        goldBalance = store.balance; sweepBalance = store.sweepBalance; canClaimDaily = false
                    }
                }, onOpen = { screen = it })
                Screen.Slots -> SlotCatalogScreen(activeBalance, currencyMode, { screen = Screen.Lobby }) { selectedSlot = it; screen = Screen.SlotGame }
                Screen.SlotGame -> SlotsScreen(activeBalance, currencyMode, selectedSlot, { screen = Screen.Slots }, ::wager, ::payout)
                Screen.Blackjack -> BlackjackScreen(activeBalance, currencyMode, { screen = Screen.Lobby }, ::wager, ::payout)
                Screen.Roulette -> RouletteScreen(activeBalance, currencyMode, { screen = Screen.Lobby }, ::wager, ::payout)
                Screen.VideoPoker -> VideoPokerScreen(activeBalance, currencyMode, { screen = Screen.Lobby }, ::wager, ::payout)
                Screen.Baccarat -> BaccaratScreen(activeBalance, currencyMode, { screen = Screen.Lobby }, ::wager, ::payout)
                Screen.Wallet -> WalletScreen(goldBalance, sweepBalance, currencyMode, canClaimDaily, onCurrency = { currencyMode = it }, onClaim = {
                    if (store.claimDaily()) { goldBalance = store.balance; sweepBalance = store.sweepBalance; canClaimDaily = false }
                })
                Screen.Profile -> ProfileScreen(store, activeBalance, currencyMode, onReset = {
                    store.reset(); goldBalance = store.balance; sweepBalance = store.sweepBalance; canClaimDaily = true
                })
                Screen.Info -> InfoScreen()
            }
        }
    }
}

@Composable
private fun Header(balance: Int, mode: CurrencyMode, compact: Boolean = false) {
    Surface(
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth().background(
            Brush.verticalGradient(listOf(Color(0xFF17191D), Color(0xFF0A0B0D)))
        )
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = if (compact) 10.dp else 17.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(10.dp), color = casinoGold) {
                    Text("GT", color = Color.Black, fontWeight = FontWeight.Black, fontSize = if (compact) 18.sp else 22.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("GARAGE TESTED", color = Color.White, fontWeight = FontWeight.Black, fontSize = if (compact) 18.sp else 22.sp, letterSpacing = 0.8.sp)
                    Text("GOLD COIN CASINO", color = casinoGold, fontWeight = FontWeight.Bold, fontSize = if (compact) 10.sp else 12.sp, letterSpacing = 1.5.sp)
                }
            }
            Surface(shape = RoundedCornerShape(50), color = Color(0xFF1C2024), border = BorderStroke(1.dp, casinoGold.copy(alpha = .55f))) {
                Text(moneyText(balance, mode), color = if (mode == CurrencyMode.SWEEP) Color(0xFF64E7C4) else Color(0xFFFFB45A), fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp))
            }
        }
    }
}

@Composable
private fun BackHeader(balance: Int, mode: CurrencyMode, title: String, onBack: () -> Unit) {
    Column {
        Header(balance, mode, compact = true)
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Text(title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 23.sp)
        }
    }
}

@Composable
private fun LobbyScreen(balance: Int, mode: CurrencyMode, dailyReady: Boolean, onCurrency: (CurrencyMode) -> Unit, onDailyBonus: () -> Unit, onOpen: (Screen) -> Unit) {
    val games = listOf(
        CasinoGame("120+ Garage Tested Slots", "Original video slots • jackpots • bonus features", "GT", Screen.Slots),
        CasinoGame("Blackjack", "Garage felt • classic 21", "♠", Screen.Blackjack),
        CasinoGame("European Roulette", "Single-zero precision wheel", "●", Screen.Roulette),
        CasinoGame("Video Poker", "Jacks or Better", "♦", Screen.VideoPoker),
        CasinoGame("Baccarat", "Player • Banker • Tie", "B", Screen.Baccarat)
    )
    LazyColumn(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0D0F12), Color.Black)))) {
        item { Header(balance, mode) }
        item {
            Column(Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
                Text("BUILT IN THE GARAGE. PLAYED FOR FUN.", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
                Text("Premium casino floor • 120+ slots • live-style table games", color = softText, fontSize = 13.sp)
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = mode == CurrencyMode.GOLD, onClick = { onCurrency(CurrencyMode.GOLD) }, label = { Text("GOLD COINS") }, modifier = Modifier.weight(1f))
                FilterChip(selected = mode == CurrencyMode.SWEEP, onClick = { onCurrency(CurrencyMode.SWEEP) }, label = { Text("SWEEP COINS") }, modifier = Modifier.weight(1f))
            }
            Text(if (mode == CurrencyMode.SWEEP) "SWEEP COINS • PROMOTIONAL PLAY • REDEMPTION LOCKED" else "GOLD COINS • SOCIAL PLAY", color = if (mode == CurrencyMode.SWEEP) Color(0xFF64E7C4) else casinoGold, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 20.dp, vertical = 3.dp))
        }
        item {
            Surface(Modifier.padding(horizontal = 18.dp).fillMaxWidth(), RoundedCornerShape(18.dp), color = steel, border = BorderStroke(1.dp, casinoGold.copy(alpha=.35f))) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(14.dp), color = casinoGold) { Icon(Icons.Default.CardGiftcard, null, tint = Color.Black, modifier = Modifier.padding(10.dp).size(26.dp)) }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("DAILY GARAGE DROP", color = Color.White, fontWeight = FontWeight.Black, fontSize = 17.sp)
                        Text(if (dailyReady) "+2,500 GC  +  SC 1.00" else "Claimed • come back tomorrow", color = if (dailyReady) casinoGold else softText)
                    }
                    Button(onClick = onDailyBonus, enabled = dailyReady, colors = ButtonDefaults.buttonColors(containerColor = casinoGold, contentColor = Color.Black)) { Text(if (dailyReady) "CLAIM" else "DONE", fontWeight = FontWeight.Black) }
                }
            }
        }
        item { Text("CASINO FLOOR", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp, modifier = Modifier.padding(18.dp, 24.dp, 18.dp, 8.dp)) }
        items(games) { game ->
            Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 7.dp), colors = CardDefaults.cardColors(containerColor = steel), shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Color(0xFF363A40)), onClick = { onOpen(game.screen) }) {
                Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(14.dp), color = if (game.screen == Screen.Roulette) Color(0xFF812020) else Color(0xFF111316), border = BorderStroke(2.dp, casinoGold.copy(alpha=.7f))) {
                        Box(Modifier.size(58.dp), contentAlignment = Alignment.Center) { Text(game.icon, color = casinoGold, fontSize = 28.sp, fontWeight = FontWeight.Black) }
                    }
                    Spacer(Modifier.width(15.dp))
                    Column(Modifier.weight(1f)) { Text(game.title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp); Text(game.subtitle, color = softText, fontSize = 13.sp) }
                    Icon(Icons.Default.ChevronRight, null, tint = casinoGold)
                }
            }
        }
        item { Text("GC = PLAY MONEY • SC = PROMOTIONAL SWEEPSTAKES CURRENCY • CASH REDEMPTION DISABLED IN THIS BUILD", color = Color(0xFF777D82), fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(20.dp)) }
    }
}

@Composable
private fun BetPicker(bet: Int, mode: CurrencyMode, enabled: Boolean = true, onBet: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.Center) {
        bets.forEach { amount ->
            FilterChip(selected = bet == amount, enabled = enabled, onClick = { onBet(amount) }, label = { Text(if (mode == CurrencyMode.GOLD) "$amount" else "%.2f".format(amount / 100.0)) }, modifier = Modifier.padding(horizontal = 3.dp))
        }
    }
}

enum class SlotSymbolType { S1, S2, S3, S4, S5, S6, WILD, BONUS }

private data class SlotWin(val payout: Int, val ways: Int, val freeSpins: Int, val label: String)

private fun weightedSlotSymbol(config: SlotGameConfig): SlotSymbolType {
    val roll = Random.nextInt(100)
    val wildChance = 5 + (config.volatility / 2)
    val bonusChance = 4
    return when {
        roll < wildChance -> SlotSymbolType.WILD
        roll < wildChance + bonusChance -> SlotSymbolType.BONUS
        roll < 25 -> SlotSymbolType.S1
        roll < 42 -> SlotSymbolType.S2
        roll < 58 -> SlotSymbolType.S3
        roll < 73 -> SlotSymbolType.S4
        roll < 87 -> SlotSymbolType.S5
        else -> SlotSymbolType.S6
    }
}

private fun slotGrid(config: SlotGameConfig): List<List<SlotSymbolType>> {
    val rows = MutableList(config.rows) { MutableList(config.reels) { weightedSlotSymbol(config) } }
    if (config.feature in listOf("STACKED WILDS", "EXPANDING WILDS") && Random.nextInt(100) < 13) {
        val col = Random.nextInt(1, config.reels)
        repeat(config.rows) { row -> rows[row][col] = SlotSymbolType.WILD }
    }
    return rows.map { it.toList() }
}

private fun evaluateWays(grid: List<List<SlotSymbolType>>, config: SlotGameConfig, bet: Int): SlotWin {
    val baseSymbols = listOf(SlotSymbolType.S1, SlotSymbolType.S2, SlotSymbolType.S3, SlotSymbolType.S4, SlotSymbolType.S5, SlotSymbolType.S6)
    val multipliers = mapOf(3 to 1, 4 to 3, 5 to 8, 6 to 18)
    var payout = 0
    var totalWays = 0
    var best = ""
    baseSymbols.forEachIndexed { symIndex, symbol ->
        var length = 0
        var ways = 1
        for (col in 0 until config.reels) {
            val count = (0 until config.rows).count { row ->
                val s = grid[row][col]
                s == symbol || s == SlotSymbolType.WILD
            }
            if (count == 0) break
            length++
            ways *= count
        }
        if (length >= 3) {
            val base = multipliers[length] ?: 0
            val symbolBoost = 1.0 + (5 - symIndex) * .18
            val volatilityScale = 0.82 + config.volatility * .12
            val divisor = (config.rows * config.rows).coerceAtLeast(9)
            val award = ((bet * base * ways * symbolBoost * volatilityScale) / divisor).toInt().coerceAtLeast(bet / 5)
            payout += award
            totalWays += ways
            if (length >= 5) best = "$length-REEL ${config.symbols[symIndex]}"
        }
    }
    val scatters = grid.sumOf { row -> row.count { it == SlotSymbolType.BONUS } }
    var free = 0
    if (scatters >= 3) {
        when (config.feature) {
            "PICK BONUS" -> {
                val pickMultiplier = listOf(5, 8, 10, 15, 20, 30, 50).random()
                payout += bet * pickMultiplier
                best = "PICK BONUS x$pickMultiplier"
            }
            "RESPINS" -> {
                free = if (scatters >= 4) 5 else 3
                payout += bet * scatters
                best = "BONUS RESPINS x$free"
            }
            else -> {
                free = when (scatters) { 3 -> 6; 4 -> 10; else -> 15 }
                payout += bet * scatters
                best = "BONUS! $free FREE SPINS"
            }
        }
    }
    if (config.feature == "MULTIPLIER WILDS" && payout > 0 && grid.flatten().count { it == SlotSymbolType.WILD } >= 2) {
        val mult = listOf(2, 3, 5).random()
        payout *= mult
        if (best.isBlank()) best = "WILD MULTIPLIER x$mult"
    }
    if (config.feature == "RESPINS" && payout > bet * 3 && free == 0) free += 1
    return SlotWin(payout, totalWays, free, best)
}

@Composable
private fun SlotCatalogScreen(balance: Int, mode: CurrencyMode, onBack: () -> Unit, onOpen: (SlotGameConfig) -> Unit) {
    var category by remember { mutableStateOf("All") }
    val filtered = remember(category) { if (category == "All") slotCatalog else slotCatalog.filter { it.category == category } }
    Column(Modifier.fillMaxSize().background(Color(0xFF060708))) {
        BackHeader(balance, mode, "SLOT FLOOR • ${slotCatalog.size} GAMES", onBack)
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            slotCategories.forEach { c ->
                FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) })
            }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                val hero = slotCatalog.first()
                SlotHeroCard(hero, Modifier.padding(12.dp).fillMaxWidth()) { onOpen(hero) }
                Text("${filtered.size} GAMES", color = softText, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp))
            }
            items(filtered.chunked(2)) { pair ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEach { game -> SlotCatalogCard(game, Modifier.weight(1f)) { onOpen(game) } }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun SlotHeroCard(config: SlotGameConfig, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val p = Color(config.primary); val s = Color(config.secondary)
    Surface(modifier.clickable(onClick = onClick), RoundedCornerShape(22.dp), color = Color.Transparent, border = BorderStroke(1.dp, p.copy(alpha=.85f)), shadowElevation = 12.dp) {
        Box(Modifier.background(Brush.horizontalGradient(listOf(s, p.copy(alpha=.82f), Color(0xFF111318)))).padding(18.dp)) {
            Column {
                Text("FEATURED GARAGE ORIGINAL", color = Color.White.copy(alpha=.75f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Text(config.title.uppercase(), color = Color.White, fontWeight = FontWeight.Black, fontSize = 25.sp)
                Text("${config.ways} WAYS • ${config.feature}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = RoundedCornerShape(50), color = Color.Black.copy(alpha=.38f)) { Text("JACKPOT  ${"%,d".format(config.jackpot)}", color = Color(0xFFFFD56A), fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal=12.dp, vertical=7.dp)) }
                    Spacer(Modifier.width(8.dp))
                    Surface(shape = RoundedCornerShape(50), color = Color.White.copy(alpha=.15f)) { Text("PLAY", color = Color.White, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal=15.dp, vertical=7.dp)) }
                }
            }
        }
    }
}

@Composable
private fun SlotCatalogCard(config: SlotGameConfig, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val p = Color(config.primary); val s = Color(config.secondary)
    Surface(modifier.clickable(onClick = onClick).height(165.dp), RoundedCornerShape(18.dp), color = Color.Transparent, border = BorderStroke(1.dp, p.copy(alpha=.7f)), shadowElevation = 7.dp) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(p.copy(alpha=.75f), s, Color(0xFF0B0C0E)))).padding(12.dp)) {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Surface(shape = RoundedCornerShape(9.dp), color = Color.Black.copy(alpha=.38f)) { Text("GT", color = Color.White, fontWeight=FontWeight.Black, modifier=Modifier.padding(7.dp)) }
                    Text("${config.ways}\nWAYS", color = Color.White, fontWeight = FontWeight.Black, fontSize = 10.sp, textAlign = TextAlign.End)
                }
                Column {
                    Text(config.title, color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp, maxLines = 2)
                    Text(config.feature, color = Color.White.copy(alpha=.78f), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Text("VOL ${"●".repeat(config.volatility)}${"○".repeat(5-config.volatility)}", color = Color(0xFFFFD36A), fontSize = 9.sp)
                }
            }
        }
    }
}

@Composable
private fun SlotSymbolFace(symbol: SlotSymbolType, label: String, primary: Color, secondary: Color, modifier: Modifier = Modifier) {
    val accent = when(symbol) {
        SlotSymbolType.WILD -> Color(0xFFFF7A00)
        SlotSymbolType.BONUS -> Color(0xFFFFD54F)
        SlotSymbolType.S1 -> primary
        SlotSymbolType.S2 -> Color(0xFF7AC7FF)
        SlotSymbolType.S3 -> Color(0xFFEC6A6A)
        SlotSymbolType.S4 -> Color(0xFFB8E986)
        SlotSymbolType.S5 -> Color(0xFFD4A6FF)
        SlotSymbolType.S6 -> Color(0xFFFFC566)
    }
    Surface(modifier, RoundedCornerShape(9.dp), color = Color(0xFF101216), border = BorderStroke(if(symbol==SlotSymbolType.WILD || symbol==SlotSymbolType.BONUS) 2.dp else 1.dp, accent), shadowElevation=4.dp) {
        Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(accent.copy(alpha=.30f), secondary.copy(alpha=.12f), Color.Transparent))), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                when(symbol) {
                    SlotSymbolType.WILD -> { Text("GT", color=Color.White, fontWeight=FontWeight.Black, fontSize=22.sp); Text("WILD", color=accent, fontWeight=FontWeight.Black, fontSize=8.sp) }
                    SlotSymbolType.BONUS -> { Icon(Icons.Default.Star, null, tint=accent, modifier=Modifier.size(27.dp)); Text("BONUS", color=accent, fontWeight=FontWeight.Black, fontSize=7.sp) }
                    SlotSymbolType.S1 -> Icon(Icons.Default.Speed, null, tint=accent, modifier=Modifier.size(27.dp))
                    SlotSymbolType.S2 -> Icon(Icons.Default.Build, null, tint=accent, modifier=Modifier.size(27.dp))
                    SlotSymbolType.S3 -> Icon(Icons.Default.Settings, null, tint=accent, modifier=Modifier.size(27.dp))
                    SlotSymbolType.S4 -> Icon(Icons.Default.LocalShipping, null, tint=accent, modifier=Modifier.size(27.dp))
                    SlotSymbolType.S5 -> Icon(Icons.Default.Diamond, null, tint=accent, modifier=Modifier.size(27.dp))
                    SlotSymbolType.S6 -> Icon(Icons.Default.MonetizationOn, null, tint=accent, modifier=Modifier.size(27.dp))
                }
                if(symbol !in listOf(SlotSymbolType.WILD, SlotSymbolType.BONUS)) Text(label, color=Color.White.copy(alpha=.88f), fontWeight=FontWeight.Black, fontSize=7.sp, maxLines=1)
            }
        }
    }
}

@Composable
private fun SlotsScreen(balance: Int, mode: CurrencyMode, config: SlotGameConfig, onBack: () -> Unit, wager: (Int) -> Boolean, payout: (Int) -> Unit) {
    var grid by remember(config.id) { mutableStateOf(slotGrid(config)) }
    var bet by remember { mutableIntStateOf(100) }
    var message by remember(config.id) { mutableStateOf("${config.ways} WAYS • ${config.feature}") }
    var isSpinning by remember { mutableStateOf(false) }
    var freeSpins by remember { mutableIntStateOf(0) }
    var lastWin by remember { mutableIntStateOf(0) }
    var jackpot by remember(config.id) { mutableIntStateOf(config.jackpot) }
    val scope = rememberCoroutineScope()
    val primary = Color(config.primary); val secondary = Color(config.secondary)

    fun spin() {
        if (isSpinning) return
        val free = freeSpins > 0
        if (!free && !wager(bet)) { message = if (mode == CurrencyMode.GOLD) "NOT ENOUGH GOLD COINS" else "NOT ENOUGH SWEEP COINS"; return }
        if (free) freeSpins--
        isSpinning = true; lastWin = 0; jackpot += (bet / 20).coerceAtLeast(1)
        message = if (free) "FREE SPIN..." else "REELS IN MOTION..."
        scope.launch {
            repeat(11) { grid = slotGrid(config); delay(52 + it*2L) }
            val finalGrid = slotGrid(config); grid = finalGrid
            var win = evaluateWays(finalGrid, config, bet)
            if (Random.nextInt(10000) == 1) win = win.copy(payout = win.payout + jackpot, label = "GARAGE JACKPOT!")
            if (win.payout > 0) payout(win.payout)
            freeSpins += win.freeSpins; lastWin = win.payout
            message = when {
                win.label == "GARAGE JACKPOT!" -> "JACKPOT! +${"%,d".format(win.payout)}"
                win.freeSpins > 0 -> "${win.label} • +${"%,d".format(win.payout)}"
                win.payout >= bet*12 -> "MEGA WIN! +${"%,d".format(win.payout)} • ${win.ways} WAYS"
                win.payout >= bet*5 -> "BIG WIN! +${"%,d".format(win.payout)} • ${win.ways} WAYS"
                win.payout > 0 -> "WIN +${"%,d".format(win.payout)} • ${win.ways} WAYS"
                else -> "NO WIN • SPIN AGAIN"
            }
            isSpinning = false
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).background(Brush.verticalGradient(listOf(secondary, Color(0xFF050607), Color.Black)))) {
        BackHeader(balance, mode, config.title, onBack)
        Box(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(secondary, primary.copy(alpha=.75f), secondary))).padding(horizontal=14.dp, vertical=12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(config.title.uppercase(), color=Color.White, fontWeight=FontWeight.Black, fontSize=20.sp)
                    Text("${config.category.uppercase()} • ${config.ways} WAYS", color=Color.White.copy(alpha=.8f), fontWeight=FontWeight.Bold, fontSize=10.sp)
                }
                Surface(shape=RoundedCornerShape(12.dp), color=Color.Black.copy(alpha=.45f), border=BorderStroke(1.dp, Color(0xFFFFD066))) {
                    Column(Modifier.padding(horizontal=11.dp, vertical=6.dp), horizontalAlignment=Alignment.End) {
                        Text("GARAGE JACKPOT", color=Color(0xFFFFD066), fontSize=8.sp, fontWeight=FontWeight.Black)
                        Text(moneyText(jackpot, mode), color=Color.White, fontSize=15.sp, fontWeight=FontWeight.Black)
                    }
                }
            }
        }
        Surface(Modifier.padding(horizontal=8.dp, vertical=10.dp).fillMaxWidth(), RoundedCornerShape(22.dp), color=Color(0xFF17191D), border=BorderStroke(2.dp, primary), shadowElevation=16.dp) {
            Column(Modifier.padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Surface(shape=RoundedCornerShape(13.dp), color=Color.Black, border=BorderStroke(2.dp, Color(0xFF4A4E55))) {
                    Column(Modifier.padding(5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        repeat(config.rows) { row ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                repeat(config.reels) { col ->
                                    val symbol=grid[row][col]
                                    val idx = when(symbol) { SlotSymbolType.S1->0; SlotSymbolType.S2->1; SlotSymbolType.S3->2; SlotSymbolType.S4->3; SlotSymbolType.S5->4; SlotSymbolType.S6->5; else->0 }
                                    SlotSymbolFace(symbol, config.symbols[idx], primary, secondary, Modifier.weight(1f).height(if(config.rows==4) 67.dp else 83.dp))
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(9.dp))
                Text(message, color=if(lastWin>0) Color(0xFFFFD066) else Color.White, fontWeight=FontWeight.Black, fontSize=14.sp, textAlign=TextAlign.Center)
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal=14.dp), horizontalArrangement=Arrangement.SpaceBetween) {
            Text("FEATURE  ${config.feature}", color=primary, fontWeight=FontWeight.Black, fontSize=11.sp)
            Text(if(freeSpins>0) "FREE SPINS $freeSpins" else "VOL ${config.volatility}/5", color=Color.White, fontWeight=FontWeight.Bold, fontSize=11.sp)
        }
        Text("TOTAL BET", color=softText, modifier=Modifier.fillMaxWidth().padding(top=8.dp), textAlign=TextAlign.Center, fontWeight=FontWeight.Bold)
        BetPicker(bet, mode, enabled=!isSpinning && freeSpins==0, onBet={bet=it})
        Button(enabled=!isSpinning, onClick={spin()}, modifier=Modifier.fillMaxWidth().padding(horizontal=18.dp, vertical=4.dp).height(68.dp), colors=ButtonDefaults.buttonColors(containerColor=primary, contentColor=Color.White)) {
            Icon(if(isSpinning) Icons.Default.Sync else Icons.Default.Casino, null, modifier=Modifier.size(27.dp)); Spacer(Modifier.width(10.dp))
            Text(when { isSpinning->"SPINNING..."; freeSpins>0->"FREE SPIN • $freeSpins LEFT"; else->"SPIN • ${moneyText(bet, mode)}" }, fontWeight=FontWeight.Black, fontSize=18.sp)
        }
        Surface(Modifier.padding(14.dp).fillMaxWidth(), RoundedCornerShape(16.dp), color=steel) {
            Column(Modifier.padding(14.dp)) {
                Text("GAME INFO", color=primary, fontWeight=FontWeight.Black)
                Text("${config.reels} reels × ${config.rows} rows • ${config.ways} ways to win", color=softText)
                Text("Feature: ${config.feature.lowercase()}", color=softText)
                Text("3+ BONUS symbols trigger free spins • WILD substitutes on ways", color=softText)
                Text(if (mode == CurrencyMode.GOLD) "Gold Coins are play money only" else "Sweep Coins are promotional; redemption is locked in this build", color=Color(0xFF888E93), fontSize=10.sp)
            }
        }
    }
}

@Composable
private fun BlackjackScreen(balance: Int, mode: CurrencyMode, onBack: () -> Unit, wager: (Int) -> Boolean, payout: (Int) -> Unit) {
    var bet by remember { mutableIntStateOf(100) }
    var deck by remember { mutableStateOf(shuffledDeck()) }
    var player by remember { mutableStateOf(emptyList<PlayingCard>()) }
    var dealer by remember { mutableStateOf(emptyList<PlayingCard>()) }
    var active by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Place a bet to deal") }

    fun finishRound() {
        var d = dealer.toMutableList()
        while (blackjackScore(d) < 17) d.add(deck.removeAt(0))
        dealer = d
        val pScore = blackjackScore(player); val dScore = blackjackScore(d)
        val result = when {
            pScore > 21 -> 0
            dScore > 21 || pScore > dScore -> bet * 2
            pScore == dScore -> bet
            else -> 0
        }
        payout(result)
        message = when { result == bet * 2 -> "You win! +${result - bet}"; result == bet -> "Push — bet returned"; else -> "Dealer wins" }
        active = false
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        BackHeader(balance, mode, "Blackjack", onBack)
        HandPanel("Dealer", dealer, if (active && dealer.isNotEmpty()) "${dealer.first().display}  🂠" else dealer.joinToString("  ") { it.display }, if (!active && dealer.isNotEmpty()) blackjackScore(dealer).toString() else "")
        HandPanel("You", player, player.joinToString("  ") { it.display }, if (player.isNotEmpty()) blackjackScore(player).toString() else "")
        Text(message, color = casinoGold, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(12.dp))
        BetPicker(bet, mode, enabled = !active, onBet = { bet = it })
        if (!active) {
            Button(onClick = {
                if (!wager(bet)) { message = "Not enough Gold Coins"; return@Button }
                deck = shuffledDeck()
                player = listOf(deck.removeAt(0), deck.removeAt(0)); dealer = listOf(deck.removeAt(0), deck.removeAt(0)); active = true
                message = "Hit or stand"
                if (blackjackScore(player) == 21) {
                    val blackjackPay = bet + (bet * 3 / 2)
                    payout(blackjackPay); message = "Blackjack! +${blackjackPay - bet}"; active = false
                }
            }, modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp)) { Text("DEAL • $bet COINS") }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 28.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = {
                    val p = player + deck.removeAt(0); player = p
                    if (blackjackScore(p) > 21) { message = "Bust — dealer wins"; active = false }
                    else if (blackjackScore(p) == 21) finishRound()
                }, modifier = Modifier.weight(1f)) { Text("HIT") }
                Button(onClick = { finishRound() }, modifier = Modifier.weight(1f)) { Text("STAND") }
            }
        }
        RulesText("Blackjack pays 3:2. Dealer stands on 17. Regular wins pay 1:1; pushes return the bet.")
    }
}

@Composable
private fun RouletteScreen(balance: Int, mode: CurrencyMode, onBack: () -> Unit, wager: (Int) -> Boolean, payout: (Int) -> Unit) {
    var bet by remember { mutableIntStateOf(100) }
    var type by remember { mutableStateOf(RouletteBet.Red) }
    var number by remember { mutableIntStateOf(7) }
    var result by remember { mutableStateOf<Int?>(null) }
    var message by remember { mutableStateOf("Choose a wager and spin") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        BackHeader(balance, mode, "European Roulette", onBack)
        RouletteWheel(result)
        Text(message, color = casinoGold, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp))
        Text("BET TYPE", color = softText, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        RouletteBet.entries.forEach { option ->
            Row(Modifier.fillMaxWidth().clickable { type = option }.padding(horizontal = 30.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = type == option, onClick = { type = option }); Text(option.label, color = Color.White)
            }
        }
        if (type == RouletteBet.Number) {
            Column(Modifier.padding(horizontal = 14.dp)) {
                Surface(modifier = Modifier.fillMaxWidth().padding(bottom=4.dp).clickable { number = 0 }, shape=RoundedCornerShape(6.dp), color = if (number==0) casinoGold else Color(0xFF087A43), border=BorderStroke(2.dp, if(number==0) Color.White else Color.Transparent)) { Text("0", color=Color.White, fontWeight=FontWeight.Black, textAlign=TextAlign.Center, modifier=Modifier.padding(8.dp)) }
                for (row in 0 until 12) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (col in 1..3) {
                            val n = row*3 + col
                            val bg = if (n in rouletteReds) Color(0xFF9E2424) else Color(0xFF171717)
                            Surface(modifier = Modifier.weight(1f).clickable { number=n }, shape=RoundedCornerShape(5.dp), color=bg, border=BorderStroke(if(number==n) 2.dp else 1.dp, if(number==n) casinoGold else Color(0xFF4A4A4A))) { Text("$n", color=Color.White, fontWeight=FontWeight.Black, textAlign=TextAlign.Center, modifier=Modifier.padding(vertical=7.dp)) }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { number = (number - 1).coerceAtLeast(0) }) { Icon(Icons.Default.Remove, null) }
                Text("$number", color = casinoGold, fontWeight = FontWeight.Black, fontSize = 28.sp, modifier = Modifier.padding(horizontal = 20.dp))
                IconButton(onClick = { number = (number + 1).coerceAtMost(36) }) { Icon(Icons.Default.Add, null) }
            }
        }
        BetPicker(bet, mode, onBet = { bet = it })
        Button(onClick = {
            if (!wager(bet)) { message = "Not enough Gold Coins"; return@Button }
            val r = randomRouletteNumber(); result = r
            val win = roulettePayout(type, number, r, bet); payout(win)
            message = if (win > 0) "Winner! Payout ${"%,d".format(win)}" else "No win this spin"
        }, modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp)) { Text("SPIN • $bet COINS") }
        RulesText("Single-zero European wheel. Red/Black/Odd/Even pay 1:1. Straight-up number pays 35:1 plus the returned stake.")
    }
}

@Composable
private fun VideoPokerScreen(balance: Int, mode: CurrencyMode, onBack: () -> Unit, wager: (Int) -> Boolean, payout: (Int) -> Unit) {
    var bet by remember { mutableIntStateOf(100) }
    var deck by remember { mutableStateOf(shuffledDeck()) }
    var hand by remember { mutableStateOf(emptyList<PlayingCard>()) }
    var held by remember { mutableStateOf(setOf<Int>()) }
    var drawing by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Deal five cards") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        BackHeader(balance, mode, "Video Poker", onBack)
        Text(message, color = casinoGold, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth().padding(12.dp), textAlign = TextAlign.Center)
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            hand.forEachIndexed { index, card ->
                PlayingCardFace(card, held = index in held, onClick = if (drawing) ({ held = if (index in held) held - index else held + index }) else null)
            }
        }
        Spacer(Modifier.height(12.dp)); BetPicker(bet, mode, enabled = !drawing, onBet = { bet = it })
        Button(onClick = {
            if (!drawing) {
                if (!wager(bet)) { message = "Not enough Gold Coins"; return@Button }
                deck = shuffledDeck(); hand = List(5) { deck.removeAt(0) }; held = emptySet(); drawing = true; message = "Tap cards to HOLD, then draw"
            } else {
                hand = hand.mapIndexed { index, card -> if (index in held) card else deck.removeAt(0) }
                val result = evaluatePoker(hand); val win = bet * result.multiplier; payout(win)
                message = if (win > 0) "${result.label}! Payout ${"%,d".format(win)}" else result.label
                drawing = false; held = emptySet()
            }
        }, modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp)) { Text(if (drawing) "DRAW" else "DEAL • $bet COINS") }
        Paytable(PokerHand.entries.filter { it.multiplier > 0 }.map { it.label to "${it.multiplier}×" })
    }
}

@Composable
private fun BaccaratScreen(balance: Int, mode: CurrencyMode, onBack: () -> Unit, wager: (Int) -> Boolean, payout: (Int) -> Unit) {
    var bet by remember { mutableIntStateOf(100) }
    var choice by remember { mutableStateOf("Player") }
    var round by remember { mutableStateOf<BaccaratRound?>(null) }
    var message by remember { mutableStateOf("Choose Player, Banker, or Tie") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        BackHeader(balance, mode, "Baccarat", onBack)
        val current = round
        HandPanel("Banker", current?.banker ?: emptyList(), current?.banker?.joinToString("  ") { it.display } ?: "—", current?.let { baccaratScore(it.banker).toString() } ?: "")
        HandPanel("Player", current?.player ?: emptyList(), current?.player?.joinToString("  ") { it.display } ?: "—", current?.let { baccaratScore(it.player).toString() } ?: "")
        Text(message, color = casinoGold, fontWeight = FontWeight.Bold, modifier = Modifier.fillMaxWidth().padding(10.dp), textAlign = TextAlign.Center)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            listOf("Player", "Banker", "Tie").forEach { option -> FilterChip(choice == option, { choice = option }, { Text(option) }, modifier = Modifier.padding(4.dp)) }
        }
        BetPicker(bet, mode, onBet = { bet = it })
        Button(onClick = {
            if (!wager(bet)) { message = "Not enough Gold Coins"; return@Button }
            val r = dealBaccarat(); round = r
            val win = when {
                choice != r.winner -> 0
                choice == "Player" -> bet * 2
                choice == "Banker" -> bankerPayout(bet)
                else -> bet * 9
            }
            payout(win); message = "${r.winner} wins" + if (win > 0) " • payout ${"%,d".format(win)}" else ""
        }, modifier = Modifier.fillMaxWidth().padding(horizontal = 28.dp)) { Text("DEAL • $bet COINS") }
        RulesText("Player pays 1:1. Banker pays 0.95:1 plus stake (5% commission). Tie pays 8:1 plus stake. Standard third-card drawing rules are applied.")
    }
}

@Composable
private fun HandPanel(title: String, hand: List<PlayingCard>, cardsText: String, scoreText: String) {
    Surface(Modifier.padding(horizontal = 18.dp, vertical = 7.dp).fillMaxWidth(), RoundedCornerShape(22.dp), color = felt, border = BorderStroke(2.dp, Color(0xFF1E6A4E))) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title.uppercase(), color = Color(0xFFD7E6DF), fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                if (scoreText.isNotEmpty()) Surface(shape = RoundedCornerShape(20.dp), color = Color.Black.copy(alpha=.35f)) { Text("$scoreText", color = casinoGold, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal=10.dp, vertical=4.dp)) }
            }
            Spacer(Modifier.height(12.dp))
            if (hand.isEmpty()) { Text("—", color = Color.White, fontSize = 28.sp) }
            else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val hideHole = cardsText.contains("🂠") && hand.size > 1
                    hand.forEachIndexed { index, card ->
                        if (hideHole && index == 1) PlayingCardBack(compact = true) else PlayingCardFace(card, compact = true)
                    }
                }
            }
        }
    }
}

@Composable
private fun PlayingCardFace(card: PlayingCard, compact: Boolean = false, held: Boolean = false, onClick: (() -> Unit)? = null) {
    val red = card.suit == "♥" || card.suit == "♦"
    Surface(
        modifier = Modifier.then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        shape = RoundedCornerShape(9.dp),
        color = if (held) Color(0xFFFFE0A8) else Color(0xFFF7F4EA),
        border = BorderStroke(if (held) 3.dp else 1.dp, if (held) casinoGold else Color(0xFFB7B7B7)),
        shadowElevation = 5.dp
    ) {
        Box(Modifier.width(if (compact) 58.dp else 62.dp).height(if (compact) 82.dp else 92.dp).padding(6.dp)) {
            Column(Modifier.align(Alignment.TopStart)) { Text(card.rank, color = if (red) Color(0xFFB11B1B) else Color(0xFF111111), fontWeight = FontWeight.Black, fontSize = 17.sp); Text(card.suit, color = if (red) Color(0xFFB11B1B) else Color.Black, fontSize = 16.sp) }
            Text(card.suit, color = if (red) Color(0xFFB11B1B) else Color.Black, fontSize = if (compact) 27.sp else 31.sp, modifier = Modifier.align(Alignment.Center))
            if (held) Text("HOLD", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 9.sp, modifier = Modifier.align(Alignment.BottomCenter))
        }
    }
}


@Composable
private fun PlayingCardBack(compact: Boolean = false) {
    Surface(shape = RoundedCornerShape(9.dp), color = Color(0xFF17191D), border = BorderStroke(2.dp, casinoGold), shadowElevation = 5.dp) {
        Box(Modifier.width(if (compact) 58.dp else 62.dp).height(if (compact) 82.dp else 92.dp).padding(6.dp), contentAlignment = Alignment.Center) {
            Surface(shape = RoundedCornerShape(6.dp), color = Color(0xFF24272C), border = BorderStroke(1.dp, casinoGold.copy(alpha=.65f))) {
                Column(Modifier.fillMaxSize().padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("GT", color = casinoGold, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    Text("GARAGE", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun RouletteWheel(result: Int?) {
    val redNumbers = rouletteReds
    Box(Modifier.fillMaxWidth().height(250.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(230.dp)) {
            val c = center; val radius = size.minDimension / 2f
            drawCircle(Color(0xFF17191D), radius)
            drawCircle(casinoGold, radius, style = Stroke(6f))
            val slices = 37
            repeat(slices) { i ->
                val start = -90f + i * (360f / slices)
                val color = when { i == 0 -> Color(0xFF087A43); i in redNumbers -> Color(0xFF9E2424); else -> Color(0xFF171717) }
                drawArc(color, start, 360f/slices, true, topLeft = Offset(c.x-radius+10, c.y-radius+10), size = Size((radius-10)*2,(radius-10)*2))
            }
            drawCircle(Color(0xFF2A2D31), radius*.43f)
            drawCircle(casinoGold, radius*.43f, style = Stroke(4f))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(result?.toString() ?: "0", color = Color.White, fontWeight = FontWeight.Black, fontSize = 48.sp); Text("GARAGE TESTED", color = casinoGold, fontSize = 10.sp, fontWeight = FontWeight.Black) }
    }
}

@Composable
private fun Paytable(rows: List<Pair<String,String>>) {
    Surface(Modifier.padding(18.dp).fillMaxWidth(), RoundedCornerShape(16.dp), color = Color(0xFF0D241A)) {
        Column(Modifier.padding(14.dp)) {
            Text("PAYTABLE", color = casinoGold, fontWeight = FontWeight.Bold)
            rows.forEach { (name, pay) -> Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(name, color = softText); Text(pay, color = Color.White) } }
        }
    }
}

@Composable
private fun RulesText(text: String) {
    Text(text, color = Color(0xFF90AF9C), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(18.dp))
}

@Composable
private fun WalletScreen(goldBalance: Int, sweepBalance: Int, mode: CurrencyMode, dailyReady: Boolean, onCurrency: (CurrencyMode) -> Unit, onClaim: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Color(0xFF07080A)).verticalScroll(rememberScrollState())) {
        Header(if (mode == CurrencyMode.GOLD) goldBalance else sweepBalance, mode)
        Text("CASINO WALLET", color=Color.White, fontWeight=FontWeight.Black, fontSize=25.sp, modifier=Modifier.padding(18.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal=18.dp), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            Card(Modifier.weight(1f), colors=CardDefaults.cardColors(containerColor=steel)) { Column(Modifier.padding(16.dp)) { Text("GOLD COINS", color=casinoGold, fontWeight=FontWeight.Black); Text("${"%,d".format(goldBalance)} GC", color=Color.White, fontSize=24.sp, fontWeight=FontWeight.Black); Text("Social play only", color=softText, fontSize=11.sp) } }
            Card(Modifier.weight(1f), colors=CardDefaults.cardColors(containerColor=Color(0xFF122A27)), border=BorderStroke(1.dp, Color(0xFF64E7C4).copy(alpha=.5f))) { Column(Modifier.padding(16.dp)) { Text("SWEEP COINS", color=Color(0xFF64E7C4), fontWeight=FontWeight.Black); Text("SC %.2f".format(sweepBalance/100.0), color=Color.White, fontSize=24.sp, fontWeight=FontWeight.Black); Text("Promotional currency", color=softText, fontSize=11.sp) } }
        }
        Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            FilterChip(selected=mode==CurrencyMode.GOLD, onClick={onCurrency(CurrencyMode.GOLD)}, label={Text("PLAY GC")}, modifier=Modifier.weight(1f))
            FilterChip(selected=mode==CurrencyMode.SWEEP, onClick={onCurrency(CurrencyMode.SWEEP)}, label={Text("PLAY SC")}, modifier=Modifier.weight(1f))
        }
        Button(onClick=onClaim, enabled=dailyReady, modifier=Modifier.fillMaxWidth().padding(horizontal=18.dp)) { Text(if(dailyReady) "CLAIM DAILY +2,500 GC + SC 1.00" else "DAILY DROP CLAIMED") }
        Surface(Modifier.padding(18.dp).fillMaxWidth(), RoundedCornerShape(16.dp), color=Color(0xFF17191D), border=BorderStroke(1.dp, Color(0xFF3B4048))) {
            Column(Modifier.padding(16.dp)) {
                Text("SWEEP COIN STATUS", color=Color(0xFF64E7C4), fontWeight=FontWeight.Black)
                Text("Promotional sweepstakes mode is active for gameplay. Cash redemption is disabled in this build.", color=Color.White)
                Text("Before redemption can be enabled: jurisdiction review, 18+/21+ age gate as applicable, KYC/identity verification, geolocation, AML/fraud controls, official sweepstakes rules, responsible-play controls, and a compliant payment/redemption provider are required.", color=softText, fontSize=12.sp)
            }
        }
    }
}

@Composable
private fun ProfileScreen(store: CasinoStore, balance: Int, mode: CurrencyMode, onReset: () -> Unit) {
    var confirmReset by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header(balance, mode)
        Text("Player Stats", color = Color.White, fontWeight = FontWeight.Black, fontSize = 28.sp, modifier = Modifier.padding(horizontal = 18.dp))
        StatCard("Games played", "${store.gamesPlayed}")
        StatCard("Total wagered", "🪙 ${"%,d".format(store.totalWagered)}")
        StatCard("Total payouts", "🪙 ${"%,d".format(store.totalWon)}")
        StatCard("Biggest payout", "🪙 ${"%,d".format(store.biggestWin)}")
        OutlinedButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth().padding(18.dp)) { Text("RESET LOCAL PROGRESS") }
    }
    if (confirmReset) AlertDialog(onDismissRequest = { confirmReset = false }, title = { Text("Reset progress?") }, text = { Text("This restores the starting 10,000 Gold Coins and clears local stats.") }, confirmButton = { TextButton(onClick = { onReset(); confirmReset = false }) { Text("Reset") } }, dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } })
}

@Composable
private fun StatCard(label: String, value: String) {
    Surface(Modifier.padding(horizontal = 18.dp, vertical = 5.dp).fillMaxWidth(), RoundedCornerShape(16.dp), color = cardGreen) {
        Row(Modifier.padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(label, color = softText); Text(value, color = Color.White, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun InfoScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Spacer(Modifier.height(10.dp)); Text("About Garage Tested Casino", color = Color.White, fontWeight = FontWeight.Black, fontSize = 28.sp)
        Spacer(Modifier.height(14.dp)); Text("A Garage Tested multi-game social casino using virtual Gold Coins for entertainment only.", color = softText, fontSize = 17.sp)
        InfoSection("Play-money only", "Gold Coins have no cash value. They cannot be redeemed, transferred, sold, or exchanged for prizes or money.")
        InfoSection("Responsible play", "Set personal time limits, take regular breaks, and treat every game as entertainment. Outcomes are randomized and there is no strategy that guarantees a win.")
        InfoSection("Privacy", "This release stores GC/SC balances and statistics locally. Sweep Coins are promotional only in this build; cash redemption is disabled. A future redeemable version requires identity, age, location, legal and responsible-play controls.")
        InfoSection("Future real-money mode", "A future real-money product would be a separate regulated feature requiring jurisdiction-specific licensing, age and identity checks, geolocation, responsible-gambling controls, secure payments, auditing, and store approval before activation.")
        InfoSection("Version", "5.0.0 • Dual-currency promotional build")
    }
}

@Composable
private fun InfoSection(title: String, body: String) {
    Surface(Modifier.padding(top = 14.dp).fillMaxWidth(), RoundedCornerShape(16.dp), color = cardGreen) {
        Column(Modifier.padding(18.dp)) { Text(title, color = casinoGold, fontWeight = FontWeight.Bold, fontSize = 18.sp); Spacer(Modifier.height(5.dp)); Text(body, color = softText) }
    }
}
