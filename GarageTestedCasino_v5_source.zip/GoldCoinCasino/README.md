# Garage Tested Casino V5

Premium Garage Tested themed Android casino prototype with 120 original slot titles plus Blackjack, European Roulette, Video Poker and Baccarat.

## Currency modes
- Gold Coins (GC): social/play-money currency.
- Sweep Coins (SC): promotional sweepstakes currency stored in hundredths (100 = SC 1.00).
- Starting balances: 10,000 GC and SC 10.00.
- Daily Garage Drop: +2,500 GC and +SC 1.00.

## Sweepstakes boundary
Sweep Coin gameplay is enabled in this prototype, but cash/prize redemption is intentionally disabled. Do not enable redemption without jurisdiction-specific legal review and production-grade age/identity verification, geolocation, fraud/AML controls, official rules, responsible-play controls, secure server-authoritative ledgers, and compliant payment/redemption infrastructure.

## Slot features
120 titles across 12 categories with varying reel formats, volatility, jackpots, symbols and feature sets. Features include free spins, stacked/expanding wilds, multiplier wilds, respins and pick bonuses.

## Build
Android API 36, Java/Kotlin 17, Jetpack Compose. Use the provided GitHub Actions workflow to produce the debug APK.
